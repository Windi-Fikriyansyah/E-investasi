<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class TransaksiController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        $transactions = DB::table('transaksi')
            ->join('produk', 'transaksi.product_id', '=', 'produk.id')
            ->select('transaksi.*', 'produk.nama_produk as product_name', 'produk.harga as product_price', 'produk.durasi', 'produk.vip', 'produk.total_pendapatan')
            ->where('transaksi.user_id', $user->id)
            ->orderByDesc('transaksi.created_at')
            ->get()
            ->map(function ($item) {
                // Add lowercase status for CSS classes while keeping original status
                $item->status_class = strtolower($item->status);

                // Calculate if the product is ready to be claimed
                $createdAt = Carbon::parse($item->created_at);
                $endDate = $createdAt->addDays($item->durasi);
                $item->can_claim = ($item->status != 'completed' && Carbon::now()->gte($endDate));

                return $item;
            });

        // Filter transactions - use original status values
        $activeTransactions = $transactions->whereIn('status', ['aktif', 'pending']);
        $completedTransactions = $transactions->where('status', 'completed');

        return view('riwayat_transaksi.index', compact('transactions', 'activeTransactions', 'completedTransactions'));
    }

    public function claim(Request $request, $id)
    {
        $user = auth()->user();

        $transaction = DB::table('transaksi')
            ->join('produk', 'transaksi.product_id', '=', 'produk.id')
            ->select('transaksi.*', 'produk.total_pendapatan', 'produk.durasi')
            ->where('transaksi.id', $id)
            ->where('transaksi.user_id', $user->id)
            ->first();

        if (!$transaction) {
            return $request->ajax()
                ? response()->json(['success' => false, 'message' => 'Transaksi tidak ditemukan'])
                : redirect()->back()->with('error', 'Transaksi tidak ditemukan');
        }

        $createdAt = Carbon::parse($transaction->created_at);
        $endDate = $createdAt->addDays($transaction->durasi);

        if ($transaction->status == 'completed') {
            return $request->ajax()
                ? response()->json(['success' => false, 'message' => 'Transaksi sudah diklaim sebelumnya'])
                : redirect()->back()->with('error', 'Transaksi sudah diklaim sebelumnya');
        }

        if (Carbon::now()->lt($endDate)) {
            return $request->ajax()
                ? response()->json(['success' => false, 'message' => 'Belum waktunya mengklaim transaksi ini'])
                : redirect()->back()->with('error', 'Belum waktunya mengklaim transaksi ini');
        }

        DB::beginTransaction();

        try {
            DB::table('users')
                ->where('id', $user->id)
                ->increment('balance', $transaction->total_pendapatan);

            DB::table('transaksi')
                ->where('id', $id)
                ->update([
                    'status' => 'completed',
                    'return_amount' => $transaction->total_pendapatan,
                    'updated_at' => now()
                ]);

            DB::commit();

            return $request->ajax()
                ? response()->json(['success' => true, 'message' => 'Klaim berhasil! Saldo Anda telah ditambahkan'])
                : redirect()->back()->with('success', 'Klaim berhasil! Saldo Anda telah ditambahkan');
        } catch (\Exception $e) {
            DB::rollBack();
            return $request->ajax()
                ? response()->json(['success' => false, 'message' => 'Gagal mengklaim: ' . $e->getMessage()])
                : redirect()->back()->with('error', 'Gagal mengklaim: ' . $e->getMessage());
        }
    }
}
