<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class ReferralController extends Controller
{
    /**
     * Display the user's profile form.
     */

    public function index()
    {
        $referralCount = User::where('referred_by', Auth::id())->count();
        return view('referral.index', compact('referralCount'));
    }
    public function bonus()
    {
        $userId = Auth::id();

        // Level 1 Team (direct referrals)
        $level1Users = DB::table('users')
            ->where('referred_by', $userId)
            ->select('id')
            ->get()
            ->pluck('id');

        $level1Count = count($level1Users);

        $level1Investors = DB::table('users')
            ->join('transaksi', 'users.id', '=', 'transaksi.user_id')
            ->where('users.referred_by', $userId)
            ->distinct('users.id')
            ->count('users.id');

        // Hitung komisi level 1 dari tabel komisi
        $level1Commission = DB::table('komisi')
            ->where('user_id', $userId)
            ->where('level', 1)
            ->sum('amount');

        // Level 2 Team (referrals of your direct referrals)
        $level2Users = DB::table('users')
            ->whereIn('referred_by', $level1Users)
            ->select('id')
            ->get()
            ->pluck('id');

        $level2Count = count($level2Users);

        $level2Investors = DB::table('users')
            ->join('transaksi', 'users.id', '=', 'transaksi.user_id')
            ->whereIn('users.referred_by', $level1Users)
            ->distinct('users.id')
            ->count('users.id');

        // Hitung komisi level 2 dari tabel komisi
        $level2Commission = DB::table('komisi')
            ->where('user_id', $userId)
            ->where('level', 2)
            ->sum('amount');

        // Level 3 Team
        $level3Users = DB::table('users')
            ->whereIn('referred_by', $level2Users)
            ->select('id')
            ->get()
            ->pluck('id');

        $level3Count = count($level3Users);

        $level3Investors = DB::table('users')
            ->join('transaksi', 'users.id', '=', 'transaksi.user_id')
            ->whereIn('users.referred_by', $level2Users)
            ->distinct('users.id')
            ->count('users.id');

        // Hitung komisi level 3 dari tabel komisi
        $level3Commission = DB::table('komisi')
            ->where('user_id', $userId)
            ->where('level', 3)
            ->sum('amount');

        $referralCount = $level1Count;

        return view('bonus.index', compact(
            'referralCount',
            'level1Count',
            'level1Investors',
            'level1Commission',
            'level2Count',
            'level2Investors',
            'level2Commission',
            'level3Count',
            'level3Investors',
            'level3Commission'
        ));
    }
}
