@extends('layouts.app')

@section('content')
    <div class="card">
        <div class="card-header-gradient">
            <div class="investment-icon">
                <i class="fas fa-user-friends"></i>
            </div>
            <div class="header-content-wrapper">
                <div class="header-title-section">
                    <h2 class="investment-title-modern">Program Referral</h2>
                    <span class="category-badge">Dapatkan Bonus</span>
                </div>
                <div class="referral-link-container">
                    <div class="referral-link-box">
                        <input type="text" id="referralLink" class="referral-link-input"
                            value="{{ url('/register?ref=' . Auth::user()->referral_code) }}" readonly>
                        <button class="copy-referral-btn" onclick="copyReferralCode(event)">
                            <i class="fas fa-copy"></i> Salin
                        </button>
                    </div>
                    <small class="referral-link-note">Bagikan link ini untuk mendapatkan komisi</small>
                </div>
            </div>
        </div>

        <div class="investment-description-modern">
            <ol>
                <li>Ketika bawahan Level 1 Anda melakukan investasi pertama, Anda bisa mendapatkan bonus sebesar 3%.</li>
                <li>Ajak teman Anda untuk melakukan isi ulang dan membeli produk investasi di WealthGrowth, Anda akan
                    mendapatkan imbalan (komisi):
                    <ul class="commission-levels">
                        <li><strong>Level 1:</strong> Komisi 30%</li>
                        <li><strong>Level 2:</strong> Komisi 3%</li>
                        <li><strong>Level 3:</strong> Komisi 1%</li>
                    </ul>
                </li>
            </ol>

            <div class="commission-examples">
                <h4>Contoh Perhitungan Komisi:</h4>
                <div class="example-item">
                    <p>Jika bawahan <strong>Level 1</strong> Anda berinvestasi <strong>Rp 1.000.000</strong>, Anda menerima
                        komisi <strong>Rp 300.000</strong></p>
                </div>
                <div class="example-item">
                    <p>Jika bawahan <strong>Level 2</strong> Anda berinvestasi <strong>Rp 1.000.000</strong>, Anda menerima
                        komisi <strong>Rp 30.000</strong></p>
                </div>
                <div class="example-item">
                    <p>Jika bawahan <strong>Level 3</strong> Anda berinvestasi <strong>Rp 1.000.000</strong>, Anda menerima
                        komisi <strong>Rp 10.000</strong></p>
                </div>
            </div>
        </div>
        <!-- Team Statistics Section -->
        <!-- Team Statistics Section -->
        <div class="team-stats-container">
            <div class="team-stat-card">
                <div class="team-stat-header" style="background: linear-gradient(135deg, #3B82F6, #1D4ED8);">
                    <h3>Tim Level 1</h3>
                </div>
                <div class="team-stat-body">
                    <div class="team-stat-item">
                        <i class="fas fa-users"></i>
                        <div>
                            <span class="team-stat-value">{{ $level1Count }}</span>
                            <span class="team-stat-label">Anggota Tim</span>
                        </div>
                    </div>
                    <div class="team-stat-item">
                        <i class="fas fa-user-check"></i>
                        <div>
                            <span class="team-stat-value">{{ $level1Investors }}</span>
                            <span class="team-stat-label">Investor Aktif</span>
                        </div>
                    </div>
                    <div class="team-stat-item">
                        <i class="fas fa-coins"></i>
                        <div>
                            <span class="team-stat-value">Rp {{ number_format($level1Commission, 0, ',', '.') }}</span>
                            <span class="team-stat-label">Total Komisi</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="team-stat-card">
                <div class="team-stat-header" style="background: linear-gradient(135deg, #10B981, #059669);">
                    <h3>Tim Level 2</h3>
                </div>
                <div class="team-stat-body">
                    <div class="team-stat-item">
                        <i class="fas fa-users"></i>
                        <div>
                            <span class="team-stat-value">{{ $level2Count }}</span>
                            <span class="team-stat-label">Anggota Tim</span>
                        </div>
                    </div>
                    <div class="team-stat-item">
                        <i class="fas fa-user-check"></i>
                        <div>
                            <span class="team-stat-value">{{ $level2Investors }}</span>
                            <span class="team-stat-label">Investor Aktif</span>
                        </div>
                    </div>
                    <div class="team-stat-item">
                        <i class="fas fa-coins"></i>
                        <div>
                            <span class="team-stat-value">Rp {{ number_format($level2Commission, 0, ',', '.') }}</span>
                            <span class="team-stat-label">Total Komisi</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="team-stat-card">
                <div class="team-stat-header" style="background: linear-gradient(135deg, #F59E0B, #D97706);">
                    <h3>Tim Level 3</h3>
                </div>
                <div class="team-stat-body">
                    <div class="team-stat-item">
                        <i class="fas fa-users"></i>
                        <div>
                            <span class="team-stat-value">{{ $level3Count }}</span>
                            <span class="team-stat-label">Anggota Tim</span>
                        </div>
                    </div>
                    <div class="team-stat-item">
                        <i class="fas fa-user-check"></i>
                        <div>
                            <span class="team-stat-value">{{ $level3Investors }}</span>
                            <span class="team-stat-label">Investor Aktif</span>
                        </div>
                    </div>
                    <div class="team-stat-item">
                        <i class="fas fa-coins"></i>
                        <div>
                            <span class="team-stat-value">Rp {{ number_format($level3Commission, 0, ',', '.') }}</span>
                            <span class="team-stat-label">Total Komisi</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="investment-stats">
            <div class="stat-highlight">
                <div class="daily-return">
                    <i class="fas fa-gift trending-icon"></i>
                    <div>
                        <div class="return-amount">30%</div>
                        <div class="return-label">Dari Investasi Teman</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Rest of your existing content... -->
        <div class="investment-description-modern">
            <!-- Your existing content -->
        </div>

        <style>
            .card {
                border: none;
                border-radius: 12px;
                overflow: hidden;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
                margin: 2px;
            }

            .card-header-gradient {
                background: linear-gradient(135deg, #088742 0%, #0ab357 100%);
                padding: 20px 15px;
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
                color: white;
                position: relative;
                overflow: hidden;
            }

            @media (min-width: 768px) {
                .card-header-gradient {
                    flex-direction: row;
                    align-items: center;
                    padding: 25px;
                    gap: 20px;
                }
            }

            .card-header-gradient::before {
                content: '';
                position: absolute;
                top: -50%;
                right: -50%;
                width: 100%;
                height: 200%;
                background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, rgba(255, 255, 255, 0) 70%);
                transform: rotate(30deg);
            }

            .investment-icon {
                font-size: 1.5rem;
                background: rgba(255, 255, 255, 0.2);
                width: 50px;
                height: 50px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
                backdrop-filter: blur(5px);
            }

            @media (min-width: 768px) {
                .investment-icon {
                    font-size: 2rem;
                    width: 60px;
                    height: 60px;
                }
            }

            .header-content-wrapper {
                flex: 1;
                display: flex;
                flex-direction: column;
                gap: 10px;
                position: relative;
                z-index: 1;
                width: 100%;
            }

            .header-title-section {
                display: flex;
                align-items: center;
                gap: 10px;
                flex-wrap: wrap;
            }

            .investment-title-modern {
                margin: 0;
                font-size: 1.25rem;
                font-weight: 700;
            }

            @media (min-width: 768px) {
                .investment-title-modern {
                    font-size: 1.5rem;
                }
            }

            .category-badge {
                background: rgba(255, 255, 255, 0.2);
                padding: 4px 10px;
                border-radius: 20px;
                font-size: 0.7rem;
                font-weight: 600;
                backdrop-filter: blur(5px);
            }

            .referral-link-container {
                margin-top: 5px;
                width: 100%;
            }

            .referral-link-box {
                display: flex;
                background: rgba(255, 255, 255, 0.2);
                border-radius: 8px;
                overflow: hidden;
                border: 1px solid rgba(255, 255, 255, 0.3);
                width: 100%;
                backdrop-filter: blur(5px);
            }

            .referral-link-input {
                flex: 1;
                padding: 8px 12px;
                background: transparent;
                border: none;
                color: white;
                font-size: 0.8rem;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                min-width: 0;
            }

            @media (min-width: 768px) {
                .referral-link-input {
                    padding: 10px 15px;
                    font-size: 0.875rem;
                }
            }

            .copy-referral-btn {
                background: rgba(255, 255, 255, 0.3);
                border: none;
                color: white;
                padding: 8px 12px;
                cursor: pointer;
                transition: all 0.3s ease;
                display: flex;
                align-items: center;
                gap: 5px;
                font-size: 0.8rem;
                font-weight: 500;
                white-space: nowrap;
            }

            @media (min-width: 768px) {
                .copy-referral-btn {
                    padding: 10px 15px;
                    font-size: 0.875rem;
                    gap: 8px;
                }
            }

            .copy-referral-btn:hover {
                background: rgba(255, 255, 255, 0.4);
            }

            .referral-link-note {
                display: block;
                margin-top: 6px;
                color: rgba(255, 255, 255, 0.85);
                font-size: 0.7rem;
            }

            @media (min-width: 768px) {
                .referral-link-note {
                    font-size: 0.75rem;
                    margin-top: 8px;
                }
            }

            /* Team stats mobile optimization */
            .team-stats-container {
                display: grid;
                grid-template-columns: 1fr;
                gap: 12px;
                padding: 12px;
            }

            @media (min-width: 640px) {
                .team-stats-container {
                    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                }
            }

            .team-stat-card {
                background: white;
                border-radius: 8px;
                overflow: hidden;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }

            .team-stat-header {
                padding: 12px;
            }

            .team-stat-header h3 {
                font-size: 15px;
            }

            .team-stat-body {
                padding: 12px;
            }

            .team-stat-item {
                margin-bottom: 10px;
            }

            .team-stat-value {
                font-size: 16px;
            }

            .team-stat-label {
                font-size: 12px;
            }

            /* Investment description mobile optimization */
            .investment-description-modern {
                padding: 15px;
            }

            .investment-description-modern ol,
            .investment-description-modern ul {
                padding-left: 20px;
            }

            .commission-examples {
                margin-top: 15px;
            }

            .example-item {
                margin-bottom: 8px;
                font-size: 0.9rem;
            }
        </style>

    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const copyButton = document.querySelector('.copy-referral-btn');
            if (copyButton) {
                copyButton.addEventListener('click', function(event) {
                    const referralLink = document.getElementById('referralLink');
                    if (referralLink) {
                        referralLink.select();
                        referralLink.setSelectionRange(0, 99999);
                        document.execCommand('copy');

                        // Show feedback
                        const originalText = event.target.innerHTML;
                        event.target.innerHTML = '<i class="fas fa-check"></i> Tersalin!';

                        setTimeout(() => {
                            event.target.innerHTML = originalText;
                        }, 2000);
                    }
                });
            }
        });
    </script>
@endsection
