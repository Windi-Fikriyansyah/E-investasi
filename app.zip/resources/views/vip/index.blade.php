@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="card vip-card">
            <div class="card-header-gradient">
                <div class="investment-icon">
                    <i class="fas fa-crown"></i>
                </div>
                <h2 class="investment-title-modern">VIP Rules</h2>
            </div>

            <div class="card-body">
                <div class="vip-description">
                    <h4>Jumlah total investasi saya</h4>
                    <p>Dengan membeli jumlah akumulasi investasi "Produk stabil", Anda dapat membuka level VIP yang berbeda
                        dan membuka lebih banyak produk VIP.</p>
                </div>

                <div class="vip-rules">
                    <h4 class="section-title">Aturan Peningkatan VIP</h4>

                    <div class="vip-levels-container">
                        <div class="vip-level">
                            <div class="vip-badge vip1">VIP1</div>
                            <div class="vip-requirement">Investasi kumulatif: <span class="amount">Rp 50.000</span></div>
                        </div>

                        <div class="vip-level">
                            <div class="vip-badge vip2">VIP2</div>
                            <div class="vip-requirement">Investasi kumulatif: <span class="amount">Rp 420.000</span></div>
                        </div>

                        <div class="vip-level">
                            <div class="vip-badge vip3">VIP3</div>
                            <div class="vip-requirement">Investasi kumulatif: <span class="amount">Rp 3.200.000</span></div>
                        </div>

                        <div class="vip-level">
                            <div class="vip-badge vip4">VIP4</div>
                            <div class="vip-requirement">Investasi kumulatif: <span class="amount">Rp 10.000.000</span>
                            </div>
                        </div>

                        <div class="vip-level">
                            <div class="vip-badge vip5">VIP5</div>
                            <div class="vip-requirement">Investasi kumulatif: <span class="amount">Rp 15.000.000</span>
                            </div>
                        </div>

                        <div class="vip-level">
                            <div class="vip-badge vip6">VIP6</div>
                            <div class="vip-requirement">Investasi kumulatif: <span class="amount">Rp 52.000.000</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        .vip-card {
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .card-header-gradient {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: white;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .investment-icon i {
            font-size: 24px;
        }

        .investment-title-modern {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 600;
        }

        .vip-description {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
        }

        .vip-description h4 {
            color: #2c3e50;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .vip-description p {
            color: #555;
            margin-bottom: 0;
            line-height: 1.6;
        }

        .section-title {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }

        .vip-levels-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }

        .vip-level {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease;
        }

        .vip-level:hover {
            transform: translateY(-5px);
        }

        .vip-badge {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: bold;
            margin-bottom: 15px;
            font-size: 1rem;
            text-align: center;
            color: white;
            min-width: 80px;
            text-transform: uppercase;
        }


        .vip1 {
            background-color: #95a5a6;
        }

        .vip2 {
            background-color: #3498db;
        }

        .vip3 {
            background-color: #2ecc71;
        }

        .vip4 {
            background-color: #f39c12;
        }

        .vip5 {
            background-color: #e74c3c;
        }

        .vip6 {
            background-color: #9b59b6;
        }

        .vip-requirement {
            font-size: 15px;
            color: #555;
        }

        .amount {
            font-weight: bold;
            color: #2c3e50;
        }

        @media (max-width: 768px) {
            .vip-levels-container {
                grid-template-columns: 1fr;
            }

            .card-header-gradient {
                padding: 15px;
            }

            .investment-title-modern {
                font-size: 1.3rem;
            }
        }
    </style>
@endsection
