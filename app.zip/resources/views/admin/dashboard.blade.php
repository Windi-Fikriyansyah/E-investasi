@extends('template.app')
@section('title', 'Dashboard')
@section('content')

@endsection
@push('js')
    <style>
        .right-gap {
            margin-right: 10px
        }
    </style>
@endpush
