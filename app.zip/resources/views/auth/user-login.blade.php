<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <div class="text-center">
                        <a href="{{ route('auth.google') }}" class="btn btn-danger">
                            <i class="fab fa-google me-2"></i> Login with Google
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
