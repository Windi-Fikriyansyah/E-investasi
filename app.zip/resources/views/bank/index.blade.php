@extends('layouts.app')

@section('content')
    <h2>Atur Rekening Bank</h2>
    <p>Kelola rekening bank Anda untuk transaksi penarikan dana.</p>

    <div class="tabs">
        <div class="tab active" data-tab="bank-list">Daftar Bank</div>
        <div class="tab" data-tab="add-bank">Tambah Bank</div>
    </div>

    <div class="tab-content active" id="bank-list">
        <div class="investment-grid">
            @forelse($banks as $bank)
                <div class="investment-card-modern">
                    <div class="card-header-gradient">
                        <div class="investment-icon">
                            <i class="fas fa-university"></i>
                        </div>
                        <h3 class="investment-title-modern">{{ $bank->nama_bank }}</h3>
                        <span class="category-badge">Aktif</span>
                    </div>

                    <div class="investment-details-modern">
                        <div class="detail-row">
                            <div class="detail-item full-width">
                                <div class="detail-icon">
                                    <i class="fas fa-credit-card"></i>
                                </div>
                                <div class="detail-content">
                                    <span class="detail-label">Nomor Rekening</span>
                                    <span class="detail-value">{{ $bank->no_rekening }}</span>
                                </div>
                            </div>
                        </div>

                        <div class="detail-row">
                            <div class="detail-item full-width">
                                <div class="detail-icon">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div class="detail-content">
                                    <span class="detail-label">Nama Pemilik</span>
                                    <span class="detail-value">{{ $bank->nama_pemilik }}</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-actions">
                        <form action="{{ route('bank.destroy', $bank->id) }}" method="POST" style="display: inline;"
                            class="delete-form">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn-detail">
                                <i class="fas fa-trash"></i> Hapus
                            </button>
                        </form>
                    </div>
                </div>
            @empty
                <div class="card" style="text-align: center; padding: 2rem;">
                    <i class="fas fa-university" style="font-size: 3rem; color: #0aa955; margin-bottom: 1rem;"></i>
                    <p style="color: #1e293b;">Anda belum menambahkan rekening bank</p>
                </div>
            @endforelse
        </div>
    </div>

    <div class="tab-content" id="add-bank">
        <div class="card">
            <h3 style="color: #1e293b;">Tambah Rekening Bank Baru</h3>
            <form action="{{ route('bank.store') }}" method="POST">
                @csrf

                <div style="margin-bottom: 1rem;">
                    <label for="nama_bank" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Nama
                        Bank</label>
                    <select name="nama_bank" id="nama_bank" class="form-control" required
                        style="width: 100%; padding: 0.75rem; border: 1px solid var(--gray); border-radius: var(--rounded-sm);">
                        <option value="">Pilih Bank</option>
                        <option value="BCA">BCA</option>
                        <option value="BRI">BRI</option>
                        <option value="Mandiri">Mandiri</option>
                        <option value="BNI">BNI</option>
                        <option value="CIMB Niaga">CIMB Niaga</option>
                        <option value="Permata">Permata</option>
                        <option value="Danamon">Danamon</option>
                        <option value="Maybank">Maybank</option>
                        <option value="OCBC NISP">OCBC NISP</option>
                        <option value="Bank Jago">Bank Jago</option>
                    </select>
                </div>

                <div style="margin-bottom: 1rem;">
                    <label for="no_rekening" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Nomor
                        Rekening</label>
                    <input type="text" name="no_rekening" id="no_rekening" required value="{{ old('no_rekening') }}"
                        style="width: 100%; padding: 0.75rem; border: 1px solid @error('no_rekening') #ef4444 @else var(--gray) @enderror; border-radius: var(--rounded-sm);"
                        placeholder="Masukkan nomor rekening tanpa spasi atau tanda baca">
                    @error('no_rekening')
                        <p style="color: #ef4444; font-size: 0.875rem; margin-top: 0.25rem;">{{ $message }}</p>
                    @enderror
                </div>

                <div style="margin-bottom: 1.5rem;">
                    <label for="nama_pemilik" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Nama
                        Pemilik Rekening</label>
                    <input type="text" name="nama_pemilik" id="nama_pemilik" required
                        style="width: 100%; padding: 0.75rem; border: 1px solid var(--gray); border-radius: var(--rounded-sm);"
                        placeholder="Nama harus sesuai dengan buku rekening">
                </div>

                <button type="submit" class="btn"
                    style="width: 100%; background: var(--primary); color: white; padding: 0.75rem; border: none; border-radius: var(--rounded-sm);">
                    <i class="fas fa-save"></i> Simpan Rekening
                </button>
            </form>
        </div>
    </div>


    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        // Format nomor rekening saat input
        document.getElementById('no_rekening').addEventListener('input', function(e) {
            // Hanya angka yang diperbolehkan
            this.value = this.value.replace(/[^0-9]/g, '');

            // Validasi panjang
            if (this.value.length > 30) {
                this.value = this.value.substring(0, 30);
                Swal.fire({
                    icon: 'warning',
                    title: 'Peringatan',
                    text: 'Nomor rekening maksimal 30 digit',
                });
            }
        });

        // Format nama pemilik (huruf besar di awal setiap kata)
        document.getElementById('nama_pemilik').addEventListener('input', function(e) {
            this.value = this.value.replace(/\b\w/g, function(char) {
                return char.toUpperCase();
            });
        });

        // Konfirmasi penghapusan dengan SweetAlert
        document.querySelectorAll('.delete-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Apakah Anda yakin?',
                    text: "Anda tidak akan dapat mengembalikan data ini!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, hapus!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                });
            });
        });

        // Tampilkan pesan sukses/gagal dari session dengan SweetAlert
        @if (session('success'))
            Swal.fire({
                icon: 'success',
                title: 'Sukses',
                text: '{{ session('success') }}',
                timer: 3000,
                showConfirmButton: false
            });
        @endif

        @if (session('error'))
            Swal.fire({
                icon: 'error',
                title: 'Gagal',
                text: '{{ session('error') }}',
                timer: 3000,
                showConfirmButton: false
            });
        @endif
    </script>
@endsection
