<!-- resources/views/components/fab.blade.php -->
<div class="fab">
    <i class="fas fa-headset"></i>
</div>
