<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="theme-color" content="#088742">
    <meta name="description" content="Platform Investasi Modern - Bangun Masa Depan Finansial Anda">
    <title>WealthGrowth | Platform Investasi Modern</title>
    <link rel="manifest" href="manifest.json">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css"
        rel="stylesheet" />

    <style>
        :root {
            --primary: #088742;
            --primary-light: #0aa955;
            --primary-dark: #077539;
            --secondary: #f0f9f4;
            --accent: #10b981;
            --accent-dark: #059669;
            --text: #1e293b;
            --text-light: #64748b;
            --white: #ffffff;
            --gray: #e2e8f0;
            --dark-gray: #94a3b8;
            --gradient: linear-gradient(135deg, #088742 0%, #10b981 100%);
            --shadow-sm: 0 1px 3px rgba(8, 135, 66, 0.1);
            --shadow-md: 0 4px 6px rgba(8, 135, 66, 0.15);
            --shadow-lg: 0 10px 15px rgba(8, 135, 66, 0.2);
            --rounded-sm: 0.5rem;
            --rounded-md: 0.75rem;
            --rounded-lg: 1rem;
            --rounded-full: 9999px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,
                Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #088742 0%, #0aa955 50%, #10b981 100%);
            color: var(--text);
            min-height: 100vh;
            line-height: 1.6;
            margin-bottom: 3rem;
            padding-top: 60px;
        }

        /* Header Styles */
        header {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),
                url('/logo.JPEG') no-repeat center center;
            background-size: cover;
            color: var(--white);
            padding: 1rem;
            text-align: center;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            overflow: hidden;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 2px solid rgba(255, 255, 255, 0.1);
        }

        .header-content {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
        }

        .btn-back {
            position: absolute;
            left: 1rem;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            font-size: 1.25rem;
            color: white;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            transition: all 0.3s ease;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(10px);
        }

        .btn-back:hover {
            background-color: rgba(255, 255, 255, 0.2);
            transform: scale(1.1);
        }

        header h1 {
            margin: 0 auto;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
            font-weight: 700;
        }

        /* Adjust for mobile view */
        @media (max-width: 640px) {
            .btn-back {
                left: 0.5rem;
                width: 36px;
                height: 36px;
            }
        }


        h1 {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0;
            position: relative;
        }

        h2 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--white);
            position: relative;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        h3 {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 0.75rem;
            color: var(--white);
        }

        p {
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 1rem;
        }

        /* Layout */
        main {
            padding: 1.5rem 1rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Hero Section */
        .hero {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            padding: 2rem 0;
            position: relative;
            z-index: 1;
        }

        .hero-text {
            max-width: 600px;
            margin-bottom: 1.5rem;
        }

        .hero-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
            flex-wrap: wrap;
            justify-content: center;
        }

        /* Carousel */
        .swiper {
            width: 100%;
            height: 220px;
            border-radius: var(--rounded-md);
            overflow: hidden;
            margin-bottom: 1.5rem;
            box-shadow: 0 10px 30px rgba(8, 135, 66, 0.3);
            border: 2px solid rgba(255, 255, 255, 0.1);
        }

        .swiper-slide {
            display: flex;
            align-items: center;
            justify-content: center;
            background-size: cover;
            background-position: center;
            position: relative;
        }

        .swiper-slide::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(8, 135, 66, 0.4);
        }

        .swiper-slide-content {
            position: relative;
            z-index: 2;
            color: white;
            padding: 1rem;
            text-align: center;
            max-width: 80%;
        }

        .swiper-slide h3 {
            color: white;
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
        }

        .swiper-slide p {
            color: rgba(255, 255, 255, 0.9);
        }

        .swiper-pagination-bullet {
            background-color: rgba(255, 255, 255, 0.5);
            opacity: 0.7;
        }

        .swiper-pagination-bullet-active {
            background-color: var(--white);
            opacity: 1;
        }

        /* Cards */
        .card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: var(--rounded-md);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 8px 25px rgba(8, 135, 66, 0.2);
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 35px rgba(8, 135, 66, 0.3);
            background: rgba(255, 255, 255, 1);
        }

        .card-icon {
            font-size: 2rem;
            color: var(--primary);
            margin-bottom: 1rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* Investment Cards */
        .investment-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: var(--rounded-md);
            overflow: hidden;
            box-shadow: 0 8px 25px rgba(8, 135, 66, 0.2);
            transition: all 0.3s ease;
            position: relative;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .investment-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 35px rgba(8, 135, 66, 0.3);
            background: rgba(255, 255, 255, 1);
        }

        .investment-badge {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background-color: var(--accent);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: var(--rounded-full);
            font-size: 0.75rem;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        }

        .investment-image {
            width: 100%;
            height: 160px;
            object-fit: cover;
        }

        .investment-info {
            padding: 1.25rem;
        }

        .investment-title {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--text);
        }

        .investment-return {
            color: var(--accent);
            font-weight: 700;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .investment-details {
            display: flex;
            justify-content: space-between;
            margin-top: 1rem;
            font-size: 0.875rem;
            color: var(--text-light);
        }

        .investment-detail-item {
            display: flex;
            flex-direction: column;
        }

        .investment-detail-value {
            font-weight: 600;
            color: var(--text);
        }

        /* Stats Card */
        .stats-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            color: white;
            padding: 1.5rem;
            border-radius: var(--rounded-md);
            margin-bottom: 1.5rem;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 25px rgba(8, 135, 66, 0.2);
        }

        .stats-card h3 {
            color: white;
            margin-bottom: 1.5rem;
            text-align: center;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1.5rem;
        }

        .stat-item {
            text-align: center;
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
        }

        .stat-label {
            font-size: 0.875rem;
            opacity: 0.9;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        /* About Section */
        .about {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            padding: 2rem 1rem;
            position: relative;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            border-radius: var(--rounded-md);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .about::before {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            background: var(--white);
            border-radius: 2px;
        }

        .about img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 1.5rem;
            border: 4px solid var(--white);
            box-shadow: 0 8px 25px rgba(8, 135, 66, 0.3);
        }

        /* Tabs */
        .tabs {
            display: flex;
            border-bottom: 1px solid rgba(255, 255, 255, 0.3);
            margin-bottom: 1.5rem;
            overflow-x: auto;
            scrollbar-width: none;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: var(--rounded-sm);
            padding: 0.5rem;
        }

        .tabs::-webkit-scrollbar {
            display: none;
        }

        .tab {
            padding: 0.75rem 1.5rem;
            cursor: pointer;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.8);
            border-bottom: 3px solid transparent;
            transition: all 0.3s ease;
            white-space: nowrap;
            border-radius: var(--rounded-sm);
        }

        .tab.active {
            background: rgba(255, 255, 255, 0.2);
            color: var(--white);
            border-bottom-color: var(--white);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        /* Investment List */
        .investment-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.5rem;
        }

        /* Bottom Navigation */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(15px);
            display: flex;
            justify-content: space-around;
            align-items: center;
            padding: 0.75rem 0;
            box-shadow: 0 -4px 20px rgba(8, 135, 66, 0.2);
            z-index: 1000;
            border-top: 1px solid rgba(8, 135, 66, 0.1);
        }

        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--text-light);
            font-size: 0.75rem;
            padding: 0.5rem;
            transition: all 0.3s ease;
            position: relative;
            border-radius: var(--rounded-sm);
        }

        .nav-item.active {
            color: var(--primary);
            background: rgba(8, 135, 66, 0.1);
        }

        .nav-item.active::after {
            content: '';
            position: absolute;
            top: -2px;
            width: 6px;
            height: 6px;
            background-color: var(--primary);
            border-radius: 50%;
        }

        .nav-item i {
            font-size: 1.25rem;
            margin-bottom: 0.25rem;
        }

        /* PWA Install Prompt */
        .install-prompt {
            position: fixed;
            bottom: 80px;
            left: 0;
            right: 0;
            background: rgba(8, 135, 66, 0.95);
            backdrop-filter: blur(15px);
            color: var(--white);
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 999;
            transform: translateY(100%);
            transition: transform 0.3s ease;
            border-top: 2px solid rgba(255, 255, 255, 0.2);
        }

        .install-prompt.show {
            transform: translateY(0);
        }

        .install-btn {
            background-color: var(--white);
            color: var(--primary);
            border: none;
            padding: 0.5rem 1rem;
            border-radius: var(--rounded-sm);
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .install-btn:hover {
            background-color: rgba(255, 255, 255, 0.9);
            transform: scale(1.05);
        }

        .close-prompt {
            background: none;
            border: none;
            color: var(--white);
            font-size: 1.25rem;
            cursor: pointer;
            margin-left: 1rem;
            padding: 0.5rem;
            border-radius: 50%;
            transition: background-color 0.3s ease;
        }

        .close-prompt:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }

        /* Button */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            background: rgba(255, 255, 255, 0.9);
            color: var(--primary);
            padding: 0.75rem 1.5rem;
            border-radius: var(--rounded-sm);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            white-space: nowrap;
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 15px rgba(255, 255, 255, 0.2);
        }

        .btn:hover {
            background-color: var(--white);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(255, 255, 255, 0.3);
        }

        .btn-outline {
            background-color: transparent;
            border: 2px solid var(--white);
            color: var(--white);
            backdrop-filter: blur(10px);
        }

        .btn-outline:hover {
            background-color: rgba(255, 255, 255, 0.1);
            color: var(--white);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(255, 255, 255, 0.2);
        }

        .btn-accent {
            background-color: var(--accent);
            color: white;
        }

        .btn-accent:hover {
            background-color: var(--accent-dark);
        }

        /* Section Header */
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .section-title {
            position: relative;
            padding-bottom: 0.5rem;
            color: var(--white);
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 3px;
            background: var(--white);
            border-radius: 3px;
        }

        /* Progress Bar */
        .progress-container {
            width: 100%;
            background-color: rgba(255, 255, 255, 0.3);
            border-radius: var(--rounded-full);
            height: 8px;
            margin: 1rem 0;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            background: var(--white);
            border-radius: var(--rounded-full);
            transition: width 0.5s ease;
        }

        /* Testimonials */
        .testimonial-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: var(--rounded-md);
            padding: 1.5rem;
            box-shadow: 0 8px 25px rgba(8, 135, 66, 0.2);
            margin-bottom: 1.5rem;
            position: relative;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .testimonial-card::before {
            content: '"';
            position: absolute;
            top: 1rem;
            left: 1rem;
            font-size: 3rem;
            color: var(--primary);
            font-family: serif;
            line-height: 1;
            opacity: 0.3;
        }

        .testimonial-content {
            padding-left: 2rem;
            margin-bottom: 1rem;
            font-style: italic;
            color: var(--text);
        }

        .testimonial-author {
            display: flex;
            align-items: center;
        }

        .testimonial-author img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 1rem;
            border: 2px solid var(--primary);
        }

        .author-info h4 {
            font-size: 1rem;
            margin-bottom: 0.25rem;
        }

        .author-info p {
            font-size: 0.875rem;
            color: var(--text-light);
            margin-bottom: 0;
        }

        /* Floating Action Button */
        .fab {
            position: fixed;
            bottom: 6rem;
            right: 1rem;
            padding: 0.75rem 1.25rem;
            border-radius: 30px;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(15px);
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 8px 25px rgba(8, 135, 66, 0.3);
            z-index: 100;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
            font-size: 0.95rem;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .fab:hover {
            transform: scale(1.05) translateY(-3px);
            box-shadow: 0 12px 35px rgba(8, 135, 66, 0.4);
            background: var(--white);
        }

        .fab i {
            font-size: 1.2rem;
        }

        /* Responsive Adjustments */
        @media (max-width: 640px) {
            .hero-buttons {
                flex-direction: column;
                width: 100%;
            }

            .hero-buttons .btn {
                width: 100%;
            }
        }

        @media (max-width: 480px) {
            .grid {
                gap: 1rem;
            }

            .card {
                padding: 1rem;
            }

            .investment-list {
                grid-template-columns: 1fr;
            }
        }

        /* Desktop View */
        @media (min-width: 768px) {
            body {
                padding-top: 0;
            }

            header {
                display: none;
            }

            .bottom-nav {
                position: static;
                flex-direction: column;
                width: 80px;
                height: 100vh;
                box-shadow: 4px 0 20px rgba(8, 135, 66, 0.2);
                justify-content: flex-start;
                padding-top: 1.5rem;
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(15px);
            }

            .nav-item {
                margin-bottom: 1.5rem;
                font-size: 0.85rem;
            }

            .nav-item i {
                font-size: 1.5rem;
            }

            body {
                display: flex;
            }

            main {
                flex-grow: 1;
                padding: 2rem;
            }

            .swiper {
                height: 300px;
            }

            h1 {
                font-size: 1.75rem;
            }
        }

        .vip-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: linear-gradient(135deg, #ffd700, #ffb347);
            color: #8b4513;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: bold;
            border: 2px solid #ffd700;
            z-index: 2;
            box-shadow: 0 4px 12px rgba(255, 215, 0, 0.3);
        }

        .investment-card {
            position: relative;
        }

        /* Style untuk tab yang aktif */
        .tab.active {
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }

        /* Investment Grid Layout */
        .investment-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 24px;
            margin-top: 24px;
        }

        /* Modern Investment Card */
        .investment-card-modern {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(15px);
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(8, 135, 66, 0.2);
            overflow: hidden;
            position: relative;
            transition: all 0.4s ease;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .investment-card-modern:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 60px rgba(8, 135, 66, 0.3);
            background: rgba(255, 255, 255, 1);
        }

        /* VIP Badge Modern */
        .vip-badge-modern {
            position: absolute;
            top: 16px;
            right: 16px;
            background: linear-gradient(135deg, #ffd700, #ffb347);
            color: #8b4513;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 4px;
            z-index: 10;
            box-shadow: 0 4px 12px rgba(255, 215, 0, 0.3);
        }

        .vip-badge-modern i {
            font-size: 10px;
        }

        /* Card Header with Gradient */
        .card-header-gradient {
            background: linear-gradient(135deg, #0aa955 0%, #088742 100%);
            padding: 50px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .card-header-gradient::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {

            0%,
            20%,
            50%,
            80%,
            100% {
                transform: rotate(0deg);
            }

            40% {
                transform: rotate(180deg);
            }

            60% {
                transform: rotate(-2px);
            }
        }

        .investment-icon {
            width: 60px;
            height: 60px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            backdrop-filter: blur(10px);
        }

        .investment-icon i {
            font-size: 24px;
            color: white;
        }

        .investment-title-modern {
            color: white;
            font-size: 18px;
            font-weight: 700;
            margin: 0 0 12px 0;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .category-badge {
            display: inline-block;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        /* Investment Stats */
        .investment-stats {
            padding: 20px 24px;
            border-bottom: 1px solid #e2e8f0;
        }

        .stat-highlight {
            text-align: center;
        }

        .daily-return {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            padding: 12px 20px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        }

        .trending-icon {
            font-size: 16px;
            animation: bounce 2s infinite;
        }

        @keyframes bounce {

            0%,
            20%,
            50%,
            80%,
            100% {
                transform: translateY(0);
            }

            40% {
                transform: translateY(-4px);
            }

            60% {
                transform: translateY(-2px);
            }
        }

        .return-amount {
            font-size: 18px;
            font-weight: 700;
        }

        .return-label {
            font-size: 12px;
            opacity: 0.9;
        }

        /* Investment Details Modern */
        .investment-details-modern {
            padding: 20px 24px;
        }

        .detail-row {
            display: flex;
            gap: 16px;
            margin-bottom: 16px;
        }

        .detail-row:last-child {
            margin-bottom: 0;
        }

        .detail-item {
            display: flex;
            align-items: center;
            flex: 1;
            gap: 12px;
        }

        .detail-item.full-width {
            flex: 1;
        }

        .detail-icon {
            width: 36px;
            height: 36px;
            background: linear-gradient(135deg, #f8fafc, #e2e8f0);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
        }

        .detail-icon i {
            font-size: 14px;
        }

        .detail-content {
            display: flex;
            flex-direction: column;
        }

        .detail-label {
            font-size: 12px;
            color: #64748b;
            font-weight: 500;
            margin-bottom: 2px;
        }

        .detail-value {
            font-size: 14px;
            font-weight: 700;
            color: #1e293b;
        }

        .total-earning {
            color: #059669;
            font-size: 16px;
        }

        /* ROI Section */
        .roi-section {
            padding: 16px 24px;
            background: linear-gradient(135deg, #f8fafc, #f1f5f9);
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid #e2e8f0;
            border-bottom: 1px solid #e2e8f0;
        }

        .roi-badge {
            display: flex;
            align-items: center;
            gap: 8px;
            background: linear-gradient(135deg, #0aa955, #088742);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            box-shadow: 0 4px 12px rgba(10, 169, 85, 0.3);
        }

        .roi-label {
            font-size: 11px;
            font-weight: 600;
            opacity: 0.9;
        }

        .roi-value {
            font-size: 14px;
            font-weight: 700;
        }

        .profit-indicator {
            font-size: 13px;
            color: #059669;
            font-weight: 600;
        }

        /* Description Modern */
        .investment-description-modern {
            padding: 20px 24px;
        }

        .investment-description-modern p {
            margin: 0;
            color: #64748b;
            font-size: 14px;
            line-height: 1.5;
        }

        /* Action Buttons */
        .card-actions {
            padding: 20px 24px;
            display: flex;
            gap: 12px;
        }

        .btn-invest {
            flex: 2;
            background: linear-gradient(135deg, #0aa955, #088742);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            box-shadow: 0 4px 12px rgba(10, 169, 85, 0.3);
        }

        .btn-invest:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(10, 169, 85, 0.4);
        }

        .btn-detail {
            flex: 1;
            background: transparent;
            color: #64748b;
            border: 2px solid #e2e8f0;
            padding: 12px 16px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }

        .btn-detail:hover {
            border-color: #0aa955;
            color: #0aa955;
            background: rgba(10, 169, 85, 0.05);
        }

        /* Progress Indicator */
        .investment-progress {
            padding: 16px 24px 20px;
            text-align: center;
        }

        .progress-bar {
            width: 100%;
            height: 6px;
            background: #e2e8f0;
            border-radius: 3px;
            overflow: hidden;
            margin-bottom: 8px;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #10b981, #059669);
            border-radius: 3px;
            transition: width 0.3s ease;
        }

        .progress-text {
            font-size: 12px;
            color: #64748b;
            font-weight: 500;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .investment-grid {
                grid-template-columns: 1fr;
                gap: 16px;
                margin-top: 16px;
            }

            .investment-card-modern {
                margin: 0 16px;
            }

            .detail-row {
                flex-direction: column;
                gap: 12px;
            }

            .roi-section {
                flex-direction: column;
                gap: 12px;
                align-items: stretch;
                text-align: center;
            }

            .card-actions {
                flex-direction: column;
            }

            .btn-invest,
            .btn-detail {
                flex: none;
            }
        }

        /* Hover Effects */
        .investment-card-modern:hover .investment-icon {
            transform: scale(1.1);
            transition: transform 0.3s ease;
        }

        .investment-card-modern:hover .roi-badge {
            transform: scale(1.05);
            transition: transform 0.3s ease;
        }

        /* Loading Animation for New Cards */
        .investment-card-modern {
            animation: fadeInUp 0.6s ease forwards;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Stagger animation for multiple cards */
        .investment-card-modern:nth-child(1) {
            animation-delay: 0.1s;
        }

        .investment-card-modern:nth-child(2) {
            animation-delay: 0.2s;
        }

        .investment-card-modern:nth-child(3) {
            animation-delay: 0.3s;
        }

        .investment-card-modern:nth-child(4) {
            animation-delay: 0.4s;
        }

        .investment-card-modern:nth-child(5) {
            animation-delay: 0.5s;
        }

        .investment-card-modern:nth-child(6) {
            animation-delay: 0.6s;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>

<body>
    <header>
        <div class="header-content">
            @if (!request()->is('/'))
                <button class="btn-back" onclick="window.history.back()">
                    <i class="fas fa-arrow-left"></i>
                </button>
            @endif
            <h1>WealthGrowth</h1>
        </div>
    </header>

    @include('layouts.sidebar')

    <main>
        @yield('content')
    </main>



    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script>
        // Initialize Swiper
        const swiper = new Swiper('.swiper', {
            loop: true,
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
        });

        // Tab Functionality
        const tabs = document.querySelectorAll('.tab');
        const tabContents = document.querySelectorAll('.tab-content');

        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const tabId = tab.getAttribute('data-tab');

                // Update active tab
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');

                // Show corresponding content
                tabContents.forEach(content => {
                    content.classList.remove('active');
                    if (content.id === tabId) {
                        content.classList.add('active');
                    }
                });
            });
        });

        // PWA Installation
        let deferredPrompt;
        const installPrompt = document.getElementById('installPrompt');
        const installBtn = document.getElementById('installBtn');
        const closePrompt = document.getElementById('closePrompt');

        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            installPrompt.classList.add('show');
        });

        installBtn.addEventListener('click', async () => {
            if (deferredPrompt) {
                deferredPrompt.prompt();
                const {
                    outcome
                } = await deferredPrompt.userChoice;
                if (outcome === 'accepted') {
                    installPrompt.classList.remove('show');
                }
                deferredPrompt = null;
            }
        });

        closePrompt.addEventListener('click', () => {
            installPrompt.classList.remove('show');
        });

        // Service Worker Registration
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('sw.js')
                    .then(registration => {
                        console.log('ServiceWorker registration successful');
                    })
                    .catch(err => {
                        console.log('ServiceWorker registration failed: ', err);
                    });
            });
        }

        // Active nav item
        const navItems = document.querySelectorAll('.nav-item');
        navItems.forEach(item => {
            item.addEventListener('click', function() {
                navItems.forEach(nav => nav.classList.remove('active'));
                this.classList.add('active');
            });
        });

        // Floating button animation
        const fab = document.querySelector('.fab');
        fab.addEventListener('click', () => {
            alert('Hubungi customer service kami untuk bantuan lebih lanjut!');
        });
    </script>
</body>

</html>
