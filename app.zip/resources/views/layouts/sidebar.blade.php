<!-- resources/views/layouts/sidebar.blade.php -->
<nav class="bottom-nav">
    <a href="{{ route('dashboard') }}" class="nav-item active">
        <i class="fas fa-home"></i>
        <span>Beranda</span>
    </a>
    <a href="{{ route('produk.index') }}" class="nav-item">
        <i class="fas fa-box"></i>
        <span>Produk</span>
    </a>
    <a href="{{ route('pesanan') }}" class="nav-item">
        <i class="fas fa-shopping-cart"></i>
        <span>Pesanan</span>
    </a>
    <a href="{{ route('bonus.index') }}" class="nav-item">
        <i class="fas fa-users"></i>
        <span>Tim</span>
    </a>

    <a href="{{ route('forum.index') }}" class="nav-item">
        <i class="fas fa-comments"></i>
        <span>Forum</span>
    </a>


    <a href="{{ route('profile.index') }}" class="nav-item">
        <i class="fas fa-user"></i>
        <span>Profil</span>
    </a>
</nav>
