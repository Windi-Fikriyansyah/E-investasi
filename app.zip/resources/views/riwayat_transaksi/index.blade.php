@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">Riwayat Transaksi</h2>

        </div>

        <div class="tabs">
            <div class="tab active" data-tab="all">Semua</div>
            <div class="tab" data-tab="active">Aktif</div>
            <div class="tab" data-tab="completed">Selesai</div>
        </div>

        <div class="tab-content active" id="all">
            <div class="transaction-list">
                @if ($transactions->count() > 0)
                    @foreach ($transactions as $transaction)
                        <div class="transaction-card {{ $transaction->vip ? 'vip' : '' }}">
                            @if ($transaction->vip)
                                <div class="vip-badge">{{ $transaction->vip }}</div>
                            @endif
                            <div class="transaction-header">
                                <div class="transaction-title">{{ $transaction->product_name }}</div>
                                <div class="transaction-amount">Rp {{ number_format($transaction->amount, 0, ',', '.') }}
                                </div>
                            </div>
                            <div class="transaction-details">
                                <div class="transaction-info">
                                    <div class="transaction-date">
                                        <i class="fas fa-calendar-alt"></i>
                                        {{ date('d M Y H:i', strtotime($transaction->created_at)) }}
                                    </div>
                                    <div class="transaction-duration">
                                        <i class="fas fa-clock"></i>
                                        Durasi: {{ $transaction->durasi }} hari
                                    </div>
                                </div>
                                <div class="transaction-status {{ $transaction->status }}">
                                    {{ ucfirst($transaction->status) }}
                                </div>
                            </div>
                            <!-- Add this inside your transaction-card div, after transaction-details -->
                            @if ($transaction->can_claim)
                                <div class="transaction-actions">
                                    <form action="{{ route('claim', $transaction->id) }}" method="POST">
                                        @csrf
                                        <button type="submit" class="claim-button">
                                            <i class="fas fa-coins"></i> Klaim
                                        </button>
                                    </form>
                                </div>
                            @endif

                            @if ($transaction->status != 'completed')
                            @else
                                <div class="transaction-return">
                                    <div class="return-label">Total Return</div>
                                    <div class="return-amount">Rp
                                        {{ number_format($transaction->return_amount ?? 0, 0, ',', '.') }}</div>
                                </div>
                            @endif
                        </div>
                    @endforeach
                @else
                    <div class="empty-state">
                        <i class="fas fa-history"></i>
                        <p>Belum ada riwayat transaksi</p>
                    </div>
                @endif
            </div>
        </div>

        <div class="tab-content" id="active">
            <div class="transaction-list">
                <!-- Konten untuk transaksi aktif -->
                @php
                    $activeTransactions = $transactions->whereIn('status', ['aktif', 'pending']);
                @endphp

                @if ($activeTransactions->count() > 0)
                    @foreach ($activeTransactions as $transaction)
                        <div class="transaction-card {{ $transaction->vip ? 'vip' : '' }}">
                            @if ($transaction->vip)
                                <div class="vip-badge">{{ $transaction->vip }}</div>
                            @endif
                            <div class="transaction-header">
                                <div class="transaction-title">{{ $transaction->product_name }}</div>
                                <div class="transaction-amount">Rp {{ number_format($transaction->amount, 0, ',', '.') }}
                                </div>
                            </div>
                            <div class="transaction-details">
                                <div class="transaction-info">
                                    <div class="transaction-date">
                                        <i class="fas fa-calendar-alt"></i>
                                        {{ date('d M Y H:i', strtotime($transaction->created_at)) }}
                                    </div>
                                    <div class="transaction-duration">
                                        <i class="fas fa-clock"></i>
                                        Durasi: {{ $transaction->durasi }} hari
                                    </div>
                                </div>
                                <div class="transaction-status {{ $transaction->status_class }}">
                                    {{ ucfirst($transaction->status) }}
                                </div>
                            </div>
                            <!-- Add this inside your transaction-card div, after transaction-details -->
                            @if ($transaction->can_claim)
                                <div class="transaction-actions">
                                    <form action="{{ route('claim', $transaction->id) }}" method="POST">
                                        @csrf
                                        <button type="submit" class="claim-button">
                                            <i class="fas fa-coins"></i> Klaim
                                        </button>
                                    </form>
                                </div>
                            @endif
                        </div>
                    @endforeach
                @else
                    <div class="empty-state">
                        <i class="fas fa-clock"></i>
                        <p>Tidak ada transaksi aktif</p>
                    </div>
                @endif
            </div>
        </div>

        <div class="tab-content" id="completed">
            <div class="transaction-list">
                <!-- Konten untuk transaksi selesai -->
                @php
                    $completedTransactions = $transactions->where('status', 'completed');
                @endphp

                @if ($completedTransactions->count() > 0)
                    @foreach ($completedTransactions as $transaction)
                        <div class="transaction-card {{ $transaction->vip ? 'vip' : '' }}">
                            @if ($transaction->vip)
                                <div class="vip-badge">{{ $transaction->vip }}</div>
                            @endif
                            <div class="transaction-header">
                                <div class="transaction-title">{{ $transaction->product_name }}</div>
                                <div class="transaction-amount">Rp {{ number_format($transaction->amount, 0, ',', '.') }}
                                </div>
                            </div>
                            <div class="transaction-details">
                                <div class="transaction-info">
                                    <div class="transaction-date">
                                        <i class="fas fa-calendar-alt"></i>
                                        {{ date('d M Y H:i', strtotime($transaction->created_at)) }}
                                    </div>
                                    <div class="transaction-duration">
                                        <i class="fas fa-clock"></i>
                                        Durasi: {{ $transaction->durasi }} hari
                                    </div>
                                </div>
                                <div class="transaction-status {{ $transaction->status }}">
                                    {{ ucfirst($transaction->status) }}
                                </div>
                            </div>
                            <div class="transaction-return">
                                <div class="return-label">Total Return</div>
                                <div class="return-amount">Rp
                                    {{ number_format($transaction->return_amount ?? 0, 0, ',', '.') }}</div>
                            </div>
                        </div>
                    @endforeach
                @else
                    <div class="empty-state">
                        <i class="fas fa-check-circle"></i>
                        <p>Tidak ada transaksi selesai</p>
                    </div>
                @endif
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    @if (session('success'))
        <script>
            Swal.fire('Sukses', '{{ session('success') }}', 'success');
        </script>
    @endif
    @if (session('error'))
        <script>
            Swal.fire('Gagal', '{{ session('error') }}', 'error');
        </script>
    @endif

    <style>
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 0.5rem;
        }

        h2 {
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            color: var(--primary-dark);
        }


        .transaction-list {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .transaction-card {
            background-color: white;
            border-radius: 0.5rem;
            padding: 1.25rem;
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            position: relative;
            border: 1px solid #e2e8f0;
        }

        .transaction-card.vip {
            border: 2px solid #f59e0b;
        }

        .vip-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: #f59e0b;
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .transaction-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        .transaction-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.75rem;
        }

        .transaction-title {
            font-weight: 600;
            color: #1e293b;
        }

        .transaction-amount {
            font-weight: 700;
            color: #3b82f6;
        }

        .transaction-actions {
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px dashed #e2e8f0;
            text-align: right;
        }

        .claim-button {
            background-color: #10b981;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .claim-button:hover {
            background-color: #059669;
        }

        .claim-button i {
            font-size: 0.875rem;
        }

        .transaction-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            font-size: 0.875rem;
        }

        .transaction-info {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .transaction-date,
        .transaction-duration {
            color: #64748b;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .transaction-status {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: capitalize;
        }

        .transaction-status.active,
        .transaction-status.aktif {
            background-color: #dcfce7;
            color: #166534;
            border: 1px solid #bbf7d0;
        }

        .transaction-status.completed {
            background-color: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }

        .transaction-status.pending {
            background-color: #fef3c7;
            color: #92400e;
            border: 1px solid #fde68a;
        }

        .transaction-progress {
            margin-top: 1rem;
        }

        .progress-container {
            width: 100%;
            background-color: #e2e8f0;
            border-radius: 9999px;
            height: 6px;
            margin-bottom: 0.5rem;
        }

        .progress-bar {
            height: 100%;
            background: linear-gradient(to right, #3b82f6, #10b981);
            border-radius: 9999px;
        }

        .progress-text {
            font-size: 0.75rem;
            color: #64748b;
            text-align: right;
        }

        .transaction-return {
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px dashed #e2e8f0;
            display: flex;
            justify-content: space-between;
        }

        .return-label {
            color: #64748b;
            font-size: 0.875rem;
        }

        .return-amount {
            font-weight: 700;
            color: #10b981;
        }

        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: #ffffff;
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: #ffffff;
        }

        .empty-state p {
            font-size: 1rem;
            margin-top: 0.5rem;
        }

        @media (max-width: 640px) {
            .transaction-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.5rem;
            }

            .transaction-details {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.5rem;
            }
        }
    </style>

    <script>
        // Tab functionality
        document.addEventListener('DOMContentLoaded', function() {
            const tabs = document.querySelectorAll('.tab');
            const tabContents = document.querySelectorAll('.tab-content');

            tabs.forEach(tab => {
                tab.addEventListener('click', () => {
                    // Remove active class from all tabs and contents
                    tabs.forEach(t => t.classList.remove('active'));
                    tabContents.forEach(c => c.classList.remove('active'));

                    // Add active class to clicked tab and corresponding content
                    tab.classList.add('active');
                    const tabId = tab.getAttribute('data-tab');
                    document.getElementById(tabId).classList.add('active');
                });
            });
        });
    </script>
@endsection
