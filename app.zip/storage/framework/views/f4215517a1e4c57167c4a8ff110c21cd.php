<div class="fab">
    <i class="fas fa-plus"></i> Posting
</div>
<?php /**PATH D:\investasi\resources\views/layouts/fab.blade.php ENDPATH**/ ?>