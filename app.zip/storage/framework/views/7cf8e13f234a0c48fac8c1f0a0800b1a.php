<?php $__env->startSection('title', 'Deposit Berhasil'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Status Deposit</h5>
                    </div>
                    <div class="card-body">
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger">
                                <h4 class="alert-heading">Error!</h4>
                                <p><?php echo e($error); ?></p>
                            </div>
                        <?php else: ?>
                            <?php if($status == 'success'): ?>
                                <div class="alert alert-success">
                                    <h4 class="alert-heading">Deposit Berhasil!</h4>
                                    <p>Pembayaran untuk Order ID: <strong><?php echo e($order_id); ?></strong> telah berhasil
                                        diproses.</p>
                                    <hr>
                                    <p class="mb-0">Saldo sebesar <strong>Rp
                                            <?php echo e(number_format($amount, 0, ',', '.')); ?></strong> telah ditambahkan ke akun
                                        Anda.</p>
                                </div>
                                <a href="<?php echo e(route('deposit.index')); ?>" class="btn btn-primary">Kembali ke Dashboard</a>
                            <?php elseif($status == 'pending'): ?>
                                <div class="alert alert-warning">
                                    <h4 class="alert-heading">Menunggu Pembayaran</h4>
                                    <p>Pembayaran untuk Order ID: <strong><?php echo e($order_id); ?></strong> masih menunggu proses
                                        pembayaran.</p>
                                    <hr>
                                    <p class="mb-0">Silakan selesaikan pembayaran Anda.</p>
                                </div>
                                <a href="<?php echo e(route('deposit.index')); ?>" class="btn btn-primary">Kembali ke Halaman
                                    Deposit</a>
                            <?php else: ?>
                                <div class="alert alert-danger">
                                    <h4 class="alert-heading">Pembayaran Gagal</h4>
                                    <p>Pembayaran untuk Order ID: <strong><?php echo e($order_id); ?></strong> tidak berhasil
                                        diproses.</p>
                                    <hr>
                                    <p class="mb-0">Silakan coba lagi atau hubungi admin.</p>
                                </div>
                                <a href="<?php echo e(route('deposit.index')); ?>" class="btn btn-primary">Coba Deposit Lagi</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\smmpanel\resources\views/deposit/success.blade.php ENDPATH**/ ?>