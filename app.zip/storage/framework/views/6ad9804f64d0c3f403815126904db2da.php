<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h2 class="section-title">Produk Investasi</h2>

    </div>

    <div class="tabs">
        <div class="tab active" data-tab="all">Semua</div>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="tab" data-tab="<?php echo e($category->kategori); ?>"><?php echo e($category->kategori); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="tab-content active" id="all">
        <div class="investment-grid">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $productVip = $product->vip ?? 'VIP 0';
                    $productVipLevel = (int) str_replace('VIP ', '', $productVip);
                    $userVipLevel = (int) str_replace('VIP ', '', Auth::user()->keanggotaan ?? 'VIP 0');
                    $isAllowed = $userVipLevel >= $productVipLevel;
                ?>

                <div class="investment-card-modern" data-product-id="<?php echo e($product->id); ?>">
                    <?php if($product->vip): ?>
                        <div class="vip-badge-modern">
                            <i class="fas fa-crown"></i>
                            <span><?php echo e($product->vip); ?></span>
                        </div>
                    <?php endif; ?>

                    <!-- Card Header with Gradient Background -->
                    <div class="card-header-gradient">

                        <h3 class="investment-title-modern"><?php echo e($product->nama_produk); ?></h3>
                        <div class="category-badge"><?php echo e($product->kategori); ?></div>
                    </div>

                    <!-- Investment Stats -->
                    <div class="investment-stats">
                        <div class="stat-highlight">
                            <div class="daily-return">
                                <i class="fas fa-arrow-up trending-icon"></i>
                                <span
                                    class="return-amount">Rp<?php echo e(number_format($product->pendapatan_harian, 0, ',', '.')); ?></span>
                                <span class="return-label">per hari</span>
                            </div>
                        </div>
                    </div>

                    <!-- Investment Details Grid -->
                    <div class="investment-details-modern">
                        <div class="detail-row">
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fas fa-tag"></i>
                                </div>
                                <div class="detail-content">
                                    <span class="detail-label">Harga Produk</span>
                                    <span class="detail-value">Rp<?php echo e(number_format($product->harga, 0, ',', '.')); ?></span>
                                </div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fas fa-clock"></i>
                                </div>
                                <div class="detail-content">
                                    <span class="detail-label">Durasi Kontrak</span>
                                    <span class="detail-value"><?php echo e($product->durasi); ?> Hari</span>
                                </div>
                            </div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-item full-width">
                                <div class="detail-icon">
                                    <i class="fas fa-money-bill-wave"></i>
                                </div>
                                <div class="detail-content">
                                    <span class="detail-label">Total Pendapatan</span>
                                    <span
                                        class="detail-value total-earning">Rp<?php echo e(number_format($product->total_pendapatan, 0, ',', '.')); ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="detail-row">
                            <div class="detail-item full-width">
                                <div class="detail-icon">
                                    <i class="fas fa-coins"></i>
                                </div>
                                <div class="detail-content">
                                    <span class="detail-label">Total Keuntungan</span>
                                    <span class="detail-value"
                                        style="color: #ffa200;">Rp<?php echo e(number_format($product->total_pendapatan - $product->harga, 0, ',', '.')); ?></span>
                                </div>
                            </div>
                        </div>




                    </div>



                    <!-- Description -->
                    <div class="investment-description-modern">
                        <p><?php echo e(Str::limit($product->keterangan, 80)); ?></p>
                    </div>

                    <!-- Action Buttons -->
                    <div class="card-actions">
                        <?php if($isAllowed): ?>
                            <button class="btn-invest">
                                <i class="fas fa-plus"></i>
                                Investasi Sekarang
                            </button>
                        <?php else: ?>
                            <div class="vip-locked">
                                <i class="fas fa-lock"></i>
                                Anda perlu minimal <?php echo e($product->vip); ?> untuk investasi ini
                            </div>
                        <?php endif; ?>
                    </div>
                    <!-- Progress Indicator (if needed) -->

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="tab-content" id="<?php echo e($category->kategori); ?>">
            <div class="investment-grid">
                <?php $__currentLoopData = $products->where('kategori', $category->kategori); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $productVip = $product->vip ?? 'VIP 0';
                        $productVipLevel = (int) str_replace('VIP ', '', $productVip);
                        $userVipLevel = (int) str_replace('VIP ', '', Auth::user()->keanggotaan ?? 'VIP 0');
                        $isAllowed = $userVipLevel >= $productVipLevel; // Selisih maksimal 1 level
                    ?>
                    <div class="investment-card-modern" data-product-id="<?php echo e($product->id); ?>">
                        <?php if($product->vip): ?>
                            <div class="vip-badge-modern">
                                <i class="fas fa-crown"></i>
                                <span><?php echo e($product->vip); ?></span>
                            </div>
                        <?php endif; ?>

                        <!-- Card Header with Gradient Background -->
                        <div class="card-header-gradient">
                            <h3 class="investment-title-modern"><?php echo e($product->nama_produk); ?></h3>
                            <div class="category-badge"><?php echo e($product->kategori); ?></div>
                        </div>

                        <!-- Investment Stats -->
                        <div class="investment-stats">
                            <div class="stat-highlight">
                                <div class="daily-return">
                                    <i class="fas fa-arrow-up trending-icon"></i>
                                    <span
                                        class="return-amount">Rp<?php echo e(number_format($product->pendapatan_harian, 0, ',', '.')); ?></span>
                                    <span class="return-label">per hari</span>
                                </div>
                            </div>
                        </div>

                        <!-- Investment Details Grid -->
                        <div class="investment-details-modern">
                            <div class="detail-row">
                                <div class="detail-item">
                                    <div class="detail-icon">
                                        <i class="fas fa-tag"></i>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Harga Produk</span>
                                        <span
                                            class="detail-value">Rp<?php echo e(number_format($product->harga, 0, ',', '.')); ?></span>
                                    </div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-icon">
                                        <i class="fas fa-clock"></i>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Durasi Kontrak</span>
                                        <span class="detail-value"><?php echo e($product->durasi); ?> Hari</span>
                                    </div>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-item full-width">
                                    <div class="detail-icon">
                                        <i class="fas fa-money-bill-wave"></i>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Total Pendapatan</span>
                                        <span
                                            class="detail-value total-earning">Rp<?php echo e(number_format($product->total_pendapatan, 0, ',', '.')); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="detail-row">
                                <div class="detail-item full-width">
                                    <div class="detail-icon">
                                        <i class="fas fa-coins"></i>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Total Keuntungan</span>
                                        <span class="detail-value"
                                            style="color: #ffa200;">Rp<?php echo e(number_format($product->total_pendapatan - $product->harga, 0, ',', '.')); ?></span>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <!-- Description -->
                        <div class="investment-description-modern">
                            <p><?php echo e(Str::limit($product->keterangan, 80)); ?></p>
                        </div>

                        <!-- Action Buttons -->
                        <div class="card-actions">
                            <?php if($isAllowed): ?>
                                <button class="btn-invest">
                                    <i class="fas fa-plus"></i>
                                    Investasi Sekarang
                                </button>
                            <?php else: ?>
                                <div class="vip-locked">
                                    <i class="fas fa-lock"></i>
                                    Anda perlu minimal <?php echo e($product->vip); ?> untuk investasi ini
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Progress Indicator -->

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Testimonials -->
    <h2 class="section-title">Apa Kata Investor Kami</h2>
    <div class="grid">
        <div class="testimonial-card">
            <div class="testimonial-content">
                Saya sudah mencoba berbagai platform investasi, tapi WealthGrowth memberikan pengalaman terbaik
                dengan antarmuka yang mudah dipahami dan return yang konsisten.
            </div>
            <div class="testimonial-author">
                <img src="https://randomuser.me/api/portraits/women/65.jpg" alt="Dian Sastrowardoyo">
                <div class="author-info">
                    <h4>Dian Sastrowardoyo</h4>
                    <p>Investor sejak 2020</p>
                </div>
            </div>
        </div>
        <div class="testimonial-card">
            <div class="testimonial-content">
                Sebagai pemula di dunia investasi, saya sangat terbantu dengan edukasi dan panduan dari
                WealthGrowth. Sekarang portofolio saya sudah tumbuh 35% dalam 2 tahun.
            </div>
            <div class="testimonial-author">
                <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Budi Santoso">
                <div class="author-info">
                    <h4>Budi Santoso</h4>
                    <p>Investor sejak 2021</p>
                </div>
            </div>
        </div>
    </div>

    <!-- About Us Card -->
    <div class="card about">
        <img src="https://images.unsplash.com/photo-1579389083078-4e7018379f7e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80"
            alt="Tim WealthGrowth">
        <h2>Tentang WealthGrowth</h2>
        <p>Kami adalah platform investasi modern yang berkomitmen untuk membuat investasi menjadi mudah diakses oleh
            semua orang. Dengan teknologi terkini dan tim ahli, kami membantu Anda membangun kekayaan jangka panjang
            dengan instrumen investasi terbaik.</p>
        <button class="btn">Pelajari Lebih Lanjut</button>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php if(session('success')): ?>
        <script>
            Swal.fire('Sukses', '<?php echo e(session('success')); ?>', 'success');
        </script>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <script>
            Swal.fire('Gagal', '<?php echo e(session('error')); ?>', 'error');
        </script>
    <?php endif; ?>
    <script>
        $(document).ready(function() {
            // Tangani klik tombol investasi
            $('.btn-invest').click(function() {
                const card = $(this).closest('.investment-card-modern');
                const productName = card.find('.investment-title-modern').text();
                const productPrice = card.find('.detail-value').first().text();
                const productId = card.data('product-id');

                Swal.fire({
                    title: 'Konfirmasi Investasi',
                    html: `Anda akan membeli <strong>${productName}</strong> seharga <strong>${productPrice}</strong>?`,
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Ya, Investasi Sekarang',
                    cancelButtonText: 'Batal',
                    reverseButtons: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Set nilai product_id dan submit form
                        $('#invest-form input[name="product_id"]').val(productId);
                        $('#invest-form').submit();
                    }
                });
            });

            // Fungsi untuk format number
            function formatNumber(num) {
                return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.')
            }
        });
    </script>
    <form id="invest-form" action="<?php echo e(route('invest')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="product_id" value="">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\investasi\resources\views/produk/index.blade.php ENDPATH**/ ?>