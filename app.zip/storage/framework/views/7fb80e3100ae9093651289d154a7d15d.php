<?php $__env->startSection('content'); ?>
    <!-- Carousel -->
    <div class="swiper">
        <div class="swiper-wrapper">
            <div class="swiper-slide" style="background-image: url('/gambar1.JPEG')">
                <div class="swiper-slide-content">
                    <h3>Investasi Emas Digital</h3>
                    <p>Mulai dari Rp10.000 dengan potensi keuntungan stabil</p>
                </div>
            </div>
            <div class="swiper-slide" style="background-image: url('/logo.JPEG')">
                <div class="swiper-slide-content">
                    <h3>Reksa Dana Terbaik</h3>
                    <p>Dikelola oleh manajer investasi profesional</p>
                </div>
            </div>
            <div class="swiper-slide"
                style="background-image: url('https://images.unsplash.com/photo-1621761191319-c6fb62004040?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1600&q=80')">
                <div class="swiper-slide-content">
                    <h3>Startup Potensial</h3>
                    <p>Investasi di perusahaan rintisan dengan prospek cerah</p>
                </div>
            </div>
        </div>
        <div class="swiper-pagination"></div>
    </div>

    <!-- Stats Card -->
    <div class="stats-card">
        <h3>Performa Platform Kami</h3>
        <div class="stats-grid">
            <div class="stat-item">
                <div class="stat-value">15.7%</div>
                <div class="stat-label">Rata-rata ROI</div>
            </div>
            <div class="stat-item">
                <div class="stat-value">125K+</div>
                <div class="stat-label">Investor</div>
            </div>
            <div class="stat-item">
                <div class="stat-value">Rp2.3T</div>
                <div class="stat-label">Aset Kelolaan</div>
            </div>
            <div class="stat-item">
                <div class="stat-value">98%</div>
                <div class="stat-label">Kepuasan</div>
            </div>
        </div>
    </div>

    <div class="grid">
        <!-- Card 1 - Tentang Kami -->
        <div class="card" style="border-top: 4px solid #088742;">
            <div class="card-icon" style="color: #088742;">
                <i class="fas fa-info-circle fa-2x"></i>
            </div>
            <h3 style="color: #1e293b;">Tentang Kami</h3>
            <p style="color: #64748b;">JOLT GIZMO CELERITY adalah platform investasi digital yang dirancang untuk memberikan
                kemudahan, transparansi, dan keuntungan berkelanjutan bagi semua kalangan. Kami percaya bahwa setiap orang
                berhak mendapatkan akses terhadap peluang investasi yang aman, terjangkau, dan menguntungkan — bahkan dengan
                modal kecil sekalipun.

                Didukung oleh tim berpengalaman di bidang keuangan dan teknologi, kami menghadirkan solusi investasi modern
                dengan return harian yang kompetitif, program referral yang menarik, serta sistem pemantauan yang transparan
                dan real-time. Kami berkomitmen penuh pada keamanan dana pengguna dengan sistem perlindungan berlapis dan
                proses yang diaudit secara berkala.

                Mulailah langkah cerdas menuju masa depan finansial yang lebih baik bersama JOLT GIZMO CELERITY. Karena kami
                percaya, satu langkah kecil hari ini dapat menjadi lompatan besar di masa depan.</p>
            <button class="btn"
                style="background-color: #088742; color: white; margin-top: 1rem; border: none; padding: 0.75rem 1.5rem; border-radius: 0.5rem; font-weight: 600; transition: all 0.3s ease;">
                Selengkapnya
            </button>
        </div>

        <!-- Card 2 - Undang Teman -->
        <div class="card" style="border-top: 4px solid #0aa955;">
            <div class="card-icon" style="color: #0aa955;">
                <i class="fas fa-user-friends fa-2x"></i>
            </div>
            <h3 style="color: #1e293b;">Undang Teman</h3>
            <p style="color: #64748b;">Dapatkan bonus 30% untuk setiap teman yang bergabung dan melakukan investasi
                pertama.</p>
            <a href="<?php echo e(route('referral.index')); ?>" class="btn"
                style="background-color: #088742; color: white; margin-top: 1rem; border: none; padding: 0.75rem 1.5rem; border-radius: 0.5rem; font-weight: 600; transition: all 0.3s ease;">
                Undang Sekarang
            </a>
        </div>

        <!-- Card 3 - Grup Resmi -->
        <div class="card" style="border-top: 4px solid #10b981;">
            <div class="card-icon" style="color: #10b981;">
                <i class="fas fa-users fa-2x"></i>
            </div>
            <h3 style="color: #1e293b;">Grup Resmi</h3>
            <p style="color: #64748b;">Bergabunglah dengan komunitas investor kami untuk mendapatkan tips dan informasi
                terbaru.</p>
            <a href="https://t.me/JOLT_GIZMO_CELERITY" target="_blank" class="btn"
                style="background-color: #088742; color: white; margin-top: 1rem; border: none; padding: 0.75rem 1.5rem; border-radius: 0.5rem; font-weight: 600; transition: all 0.3s ease;">
                Gabung Grup
            </a>
        </div>

        <!-- Card 4 - Penarikan Cepat -->
        <div class="card" style="border-top: 4px solid #059669;">
            <div class="card-icon" style="color: #059669;">
                <i class="fas fa-wallet fa-2x"></i>
            </div>
            <h3 style="color: #1e293b;">Penarikan Cepat</h3>
            <p style="color: #64748b;">Proses penarikan dana hanya membutuhkan waktu 1-2 jam kerja ke rekening Anda.</p>
            <a href="<?php echo e(route('withdrawal.index')); ?>" class="btn"
                style="background-color: #088742; color: white; margin-top: 1rem; border: none; padding: 0.75rem 1.5rem; border-radius: 0.5rem; font-weight: 600; transition: all 0.3s ease;">
                Tarik Dana
            </a>
        </div>
    </div>

    <!-- Investment Products -->
    <div class="section-header">
        <h2 class="section-title">Produk Investasi</h2>

    </div>

    <div class="tabs">
        <div class="tab active" data-tab="all">Semua</div>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="tab" data-tab="<?php echo e($category->kategori); ?>"><?php echo e($category->kategori); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="tab-content active" id="all">
        <div class="investment-grid">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $productVip = $product->vip ?? 'VIP 0';
                    $productVipLevel = (int) str_replace('VIP ', '', $productVip);
                    $userVipLevel = (int) str_replace('VIP ', '', Auth::user()->keanggotaan ?? 'VIP 0');
                    $isAllowed = $userVipLevel >= $productVipLevel;
                ?>

                <div class="investment-card-modern" data-product-id="<?php echo e($product->id); ?>">
                    <?php if($product->vip): ?>
                        <div class="vip-badge-modern">
                            <i class="fas fa-crown"></i>
                            <span><?php echo e($product->vip); ?></span>
                        </div>
                    <?php endif; ?>

                    <!-- Card Header with Gradient Background -->
                    <div class="card-header-gradient">

                        <h3 class="investment-title-modern"><?php echo e($product->nama_produk); ?></h3>
                        <div class="category-badge"><?php echo e($product->kategori); ?></div>
                    </div>

                    <!-- Investment Stats -->
                    <div class="investment-stats">
                        <div class="stat-highlight">
                            <div class="daily-return">
                                <i class="fas fa-arrow-up trending-icon"></i>
                                <span
                                    class="return-amount">Rp<?php echo e(number_format($product->pendapatan_harian, 0, ',', '.')); ?></span>
                                <span class="return-label">per hari</span>
                            </div>
                        </div>
                    </div>

                    <!-- Investment Details Grid -->
                    <div class="investment-details-modern">
                        <div class="detail-row">
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fas fa-tag"></i>
                                </div>
                                <div class="detail-content">
                                    <span class="detail-label">Harga Produk</span>
                                    <span class="detail-value">Rp<?php echo e(number_format($product->harga, 0, ',', '.')); ?></span>
                                </div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fas fa-clock"></i>
                                </div>
                                <div class="detail-content">
                                    <span class="detail-label">Durasi Kontrak</span>
                                    <span class="detail-value"><?php echo e($product->durasi); ?> Hari</span>
                                </div>
                            </div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-item full-width">
                                <div class="detail-icon">
                                    <i class="fas fa-money-bill-wave"></i>
                                </div>
                                <div class="detail-content">
                                    <span class="detail-label">Total Pendapatan</span>
                                    <span
                                        class="detail-value total-earning">Rp<?php echo e(number_format($product->total_pendapatan, 0, ',', '.')); ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="detail-row">
                            <div class="detail-item full-width">
                                <div class="detail-icon">
                                    <i class="fas fa-coins"></i>
                                </div>
                                <div class="detail-content">
                                    <span class="detail-label">Total Keuntungan</span>
                                    <span class="detail-value"
                                        style="color: #ffa200;">Rp<?php echo e(number_format($product->total_pendapatan - $product->harga, 0, ',', '.')); ?></span>
                                </div>
                            </div>
                        </div>




                    </div>



                    <!-- Description -->
                    <div class="investment-description-modern">
                        <p><?php echo e(Str::limit($product->keterangan, 80)); ?></p>
                    </div>

                    <!-- Action Buttons -->
                    <div class="card-actions">
                        <?php if($isAllowed): ?>
                            <button class="btn-invest">
                                <i class="fas fa-plus"></i>
                                Investasi Sekarang
                            </button>
                        <?php else: ?>
                            <div class="vip-locked">
                                <i class="fas fa-lock"></i>
                                Anda perlu minimal <?php echo e($product->vip); ?> untuk investasi ini
                            </div>
                        <?php endif; ?>
                    </div>
                    <!-- Progress Indicator (if needed) -->

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="tab-content" id="<?php echo e($category->kategori); ?>">
            <div class="investment-grid">
                <?php $__currentLoopData = $products->where('kategori', $category->kategori); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $productVip = $product->vip ?? 'VIP 0';
                        $productVipLevel = (int) str_replace('VIP ', '', $productVip);
                        $userVipLevel = (int) str_replace('VIP ', '', Auth::user()->keanggotaan ?? 'VIP 0');
                        $isAllowed = $userVipLevel >= $productVipLevel; // Selisih maksimal 1 level
                    ?>
                    <div class="investment-card-modern" data-product-id="<?php echo e($product->id); ?>">
                        <?php if($product->vip): ?>
                            <div class="vip-badge-modern">
                                <i class="fas fa-crown"></i>
                                <span><?php echo e($product->vip); ?></span>
                            </div>
                        <?php endif; ?>

                        <!-- Card Header with Gradient Background -->
                        <div class="card-header-gradient">
                            <h3 class="investment-title-modern"><?php echo e($product->nama_produk); ?></h3>
                            <div class="category-badge"><?php echo e($product->kategori); ?></div>
                        </div>

                        <!-- Investment Stats -->
                        <div class="investment-stats">
                            <div class="stat-highlight">
                                <div class="daily-return">
                                    <i class="fas fa-arrow-up trending-icon"></i>
                                    <span
                                        class="return-amount">Rp<?php echo e(number_format($product->pendapatan_harian, 0, ',', '.')); ?></span>
                                    <span class="return-label">per hari</span>
                                </div>
                            </div>
                        </div>

                        <!-- Investment Details Grid -->
                        <div class="investment-details-modern">
                            <div class="detail-row">
                                <div class="detail-item">
                                    <div class="detail-icon">
                                        <i class="fas fa-tag"></i>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Harga Produk</span>
                                        <span
                                            class="detail-value">Rp<?php echo e(number_format($product->harga, 0, ',', '.')); ?></span>
                                    </div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-icon">
                                        <i class="fas fa-clock"></i>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Durasi Kontrak</span>
                                        <span class="detail-value"><?php echo e($product->durasi); ?> Hari</span>
                                    </div>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-item full-width">
                                    <div class="detail-icon">
                                        <i class="fas fa-money-bill-wave"></i>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Total Pendapatan</span>
                                        <span
                                            class="detail-value total-earning">Rp<?php echo e(number_format($product->total_pendapatan, 0, ',', '.')); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="detail-row">
                                <div class="detail-item full-width">
                                    <div class="detail-icon">
                                        <i class="fas fa-coins"></i>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Total Keuntungan</span>
                                        <span class="detail-value"
                                            style="color: #ffa200;">Rp<?php echo e(number_format($product->total_pendapatan - $product->harga, 0, ',', '.')); ?></span>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <!-- Description -->
                        <div class="investment-description-modern">
                            <p><?php echo e(Str::limit($product->keterangan, 80)); ?></p>
                        </div>

                        <!-- Action Buttons -->
                        <div class="card-actions">
                            <?php if($isAllowed): ?>
                                <button class="btn-invest">
                                    <i class="fas fa-plus"></i>
                                    Investasi Sekarang
                                </button>
                            <?php else: ?>
                                <div class="vip-locked">
                                    <i class="fas fa-lock"></i>
                                    Anda perlu minimal <?php echo e($product->vip); ?> untuk investasi ini
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Progress Indicator -->

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Testimonials -->
    <h2 class="section-title">Apa Kata Investor Kami</h2>
    <div class="grid">
        <div class="testimonial-card">
            <div class="testimonial-content">
                Saya sudah mencoba berbagai platform investasi, tapi WealthGrowth memberikan pengalaman terbaik
                dengan antarmuka yang mudah dipahami dan return yang konsisten.
            </div>
            <div class="testimonial-author">
                <img src="https://randomuser.me/api/portraits/women/65.jpg" alt="Dian Sastrowardoyo">
                <div class="author-info">
                    <h4>Dian Sastrowardoyo</h4>
                    <p>Investor sejak 2020</p>
                </div>
            </div>
        </div>
        <div class="testimonial-card">
            <div class="testimonial-content">
                Sebagai pemula di dunia investasi, saya sangat terbantu dengan edukasi dan panduan dari
                WealthGrowth. Sekarang portofolio saya sudah tumbuh 35% dalam 2 tahun.
            </div>
            <div class="testimonial-author">
                <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Budi Santoso">
                <div class="author-info">
                    <h4>Budi Santoso</h4>
                    <p>Investor sejak 2021</p>
                </div>
            </div>
        </div>
    </div>

    <!-- About Us Card -->
    <div class="card about">
        <img src="https://images.unsplash.com/photo-1579389083078-4e7018379f7e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80"
            alt="Tim WealthGrowth">
        <h2>Tentang WealthGrowth</h2>
        <p>Kami adalah platform investasi modern yang berkomitmen untuk membuat investasi menjadi mudah diakses oleh
            semua orang. Dengan teknologi terkini dan tim ahli, kami membantu Anda membangun kekayaan jangka panjang
            dengan instrumen investasi terbaik.</p>
        <button class="btn">Pelajari Lebih Lanjut</button>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if(session('registered')): ?>
        <script>
            Swal.fire({
                title: 'Selamat Bergabung!',
                text: 'Selamat! Anda mendapatkan bonus saldo sebesar Rp5.000',
                icon: 'success',
                confirmButtonText: 'Mulai Investasi'
            });
        </script>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <script>
            Swal.fire('Sukses', '<?php echo e(session('success')); ?>', 'success');
        </script>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <script>
            Swal.fire('Gagal', '<?php echo e(session('error')); ?>', 'error');
        </script>
    <?php endif; ?>
    <script>
        $(document).ready(function() {
            // Tangani klik tombol investasi
            $('.btn-invest').click(function() {
                const card = $(this).closest('.investment-card-modern');
                const productName = card.find('.investment-title-modern').text();
                const productPrice = card.find('.detail-value').first().text();
                const productId = card.data('product-id');

                Swal.fire({
                    title: 'Konfirmasi Investasi',
                    html: `Anda akan membeli <strong>${productName}</strong> seharga <strong>${productPrice}</strong>?`,
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Ya, Investasi Sekarang',
                    cancelButtonText: 'Batal',
                    reverseButtons: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Set nilai product_id dan submit form
                        $('#invest-form input[name="product_id"]').val(productId);
                        $('#invest-form').submit();
                    }
                });
            });

            // Fungsi untuk format number
            function formatNumber(num) {
                return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.')
            }
        });
    </script>
    <form id="invest-form" action="<?php echo e(route('invest')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="product_id" value="">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\investasi\resources\views/dashboard.blade.php ENDPATH**/ ?>