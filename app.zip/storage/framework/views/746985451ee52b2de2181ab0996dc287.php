<ul class="menu-inner py-1">
    <!-- Dashboard -->
    <li class="menu-item active">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="menu-link">
            <i class="menu-icon tf-icons bx bx-home-circle"></i>
            <div data-i18n="Analytics">Dashboard</div>
        </a>
    </li>

    <li class="menu-header small text-uppercase">
        <span class="menu-header-text">Setting</span>
    </li>
    <li class="menu-item">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
            <i class="menu-icon tf-icons bx bx-dock-top"></i>
            <div data-i18n="Account Settings">Setting API</div>
        </a>
        <ul class="menu-sub">
            <li class="menu-item">
                <a href="<?php echo e(route('admin.api_supplier.index')); ?>" class="menu-link">
                    <div data-i18n="Account">API Supplier</div>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?php echo e(route('admin.midtrans_settings.index')); ?>" class="menu-link">
                    <div data-i18n="Notifications">API Midtrans</div>
                </a>
            </li>

        </ul>
    </li>


    <li class="menu-item">
        <a href="<?php echo e(route('admin.user.index')); ?>" class="menu-link">
            <i class="menu-icon tf-icons bx bx-table"></i>
            <div data-i18n="Tables">Manajemen Pengguna</div>
        </a>
    </li>


    <li class="menu-item">
        <a href="<?php echo e(route('admin.layanan.index')); ?>" class="menu-link">
            <i class="menu-icon tf-icons bx bx-table"></i>
            <div data-i18n="Tables">Layanan (Service)</div>
        </a>
    </li>

    <li class="menu-item">
        <a href="<?php echo e(route('admin.markup.index')); ?>" class="menu-link">
            <i class="menu-icon tf-icons bx bx-table"></i>
            <div data-i18n="Tables">Markup Harga</div>
        </a>
    </li>

    <li class="menu-item">
        <a href="<?php echo e(route('deposit.index')); ?>" class="menu-link">
            <i class="menu-icon tf-icons bx bx-table"></i>
            <div data-i18n="Tables">Deposit</div>
        </a>
    </li>
    <li class="menu-item">
        <a href="<?php echo e(route('order.index')); ?>" class="menu-link">
            <i class="menu-icon tf-icons bx bx-table"></i>
            <div data-i18n="Tables">Order</div>
        </a>
    </li>


</ul>
<?php /**PATH D:\smmpanel\resources\views/template/sidebar.blade.php ENDPATH**/ ?>