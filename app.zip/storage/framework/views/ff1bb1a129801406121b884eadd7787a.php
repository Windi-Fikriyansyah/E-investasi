<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <style>
        .right-gap {
            margin-right: 10px
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\investasi\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>