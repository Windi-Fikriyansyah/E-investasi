<?php $__env->startSection('title', 'Deposit'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Deposit Saldo</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('deposit.create')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="amount">Jumlah Deposit</label>
                                <div class="col-sm-10">
                                    <div class="input-group">
                                        <span class="input-group-text">Rp</span>
                                        <input type="text" id="amount" name="amount"
                                            class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('amount')); ?>" placeholder="Minimum Rp 10.000" required>
                                    </div>
                                    <input type="hidden" id="amount_raw" name="amount_raw">
                                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <small class="text-muted">Minimum deposit Rp 10.000</small>
                                </div>
                            </div>

                            <div class="row justify-content-end">
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-primary">Lanjutkan Pembayaran</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h5>Riwayat Deposit</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" id="depositTable">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Order ID</th>
                                <th>Jumlah</th>
                                <th>Status</th>
                                <th>Tanggal</th>
                                <th>Metode</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Data riwayat deposit akan diisi via AJAX atau server-side -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Konfirmasi Pembatalan -->
    <div class="modal fade" id="cancelModal" tabindex="-1" aria-labelledby="cancelModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="cancelModalLabel">Konfirmasi Pembatalan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Apakah Anda yakin ingin membatalkan transaksi deposit ini?</p>
                    <p class="text-muted">Order ID: <span id="cancelOrderId"></span></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tidak</button>
                    <button type="button" class="btn btn-danger" id="confirmCancel">Ya, Batalkan</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            $('#amount').on('keyup', function() {
                let value = $(this).val().replace(/\D/g, '');
                $('#amount_raw').val(value); // Simpan nilai numerik ke hidden input

                if (value.length > 0) {
                    // Format dengan titik sebagai pemisah ribuan
                    let formatted = new Intl.NumberFormat('id-ID').format(value);
                    $(this).val(formatted);
                }
            });
            $('form').on('submit', function(e) {
                let rawValue = $('#amount_raw').val();
                if (!rawValue || parseInt(rawValue) < 10000) {
                    e.preventDefault();
                    alert('Minimum deposit adalah Rp 10.000');
                    return false;
                }
            });
            // Inisialisasi DataTable untuk riwayat deposit
            $('#depositTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('deposit.history')); ?>",
                columns: [{
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'order_id',
                        name: 'order_id'
                    },
                    {
                        data: 'amount',
                        name: 'amount',
                        render: function(data) {
                            return 'Rp ' + data.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                        }
                    },
                    {
                        data: 'status',
                        name: 'status',
                        render: function(data) {
                            let badgeClass = 'badge bg-label-';
                            switch (data) {
                                case 'success':
                                    badgeClass += 'success';
                                    break;
                                case 'pending':
                                    badgeClass += 'warning';
                                    break;
                                case 'failed':
                                    badgeClass += 'danger';
                                    break;
                                default:
                                    badgeClass += 'danger';
                            }
                            return '<span class="' + badgeClass + '">' + data + '</span>';
                        }
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'payment_method',
                        name: 'payment_method'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    }
                ]
            });

            // Handle tombol lanjutkan pembayaran
            $(document).on('click', '.btn-continue', function() {
                const orderId = $(this).data('order-id');
                const amount = $(this).data('amount');

                // Redirect ke halaman pembayaran dengan order_id
                window.location.href = "<?php echo e(route('deposit.continue')); ?>?order_id=" + orderId;
            });

            // Handle tombol batalkan
            $(document).on('click', '.btn-cancel', function() {
                const orderId = $(this).data('order-id');
                $('#cancelOrderId').text(orderId);
                $('#confirmCancel').data('order-id', orderId);
                $('#cancelModal').modal('show');
            });

            // Handle konfirmasi pembatalan
            $('#confirmCancel').click(function() {
                const orderId = $(this).data('order-id');

                $.ajax({
                    url: "<?php echo e(route('deposit.cancel')); ?>",
                    method: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        order_id: orderId
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#cancelModal').modal('hide');
                            $('#depositTable').DataTable().ajax.reload();

                            // Tampilkan pesan sukses
                            toastr.success('Transaksi berhasil dibatalkan');
                        } else {
                            toastr.error(response.message || 'Gagal membatalkan transaksi');
                        }
                    },
                    error: function(xhr) {
                        toastr.error('Terjadi kesalahan saat membatalkan transaksi');
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\smmpanel\resources\views/deposit/index.blade.php ENDPATH**/ ?>