<?php $__env->startSection('title', 'Produk'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-header d-flex align-items-center justify-content-between">
                        <h5 class="mb-0"><?php echo e(isset($produk) ? 'Edit' : 'Tambah'); ?> Produk</h5>
                        <small class="text-muted float-end">Form Produk</small>
                    </div>
                    <div class="card-body">
                        <form
                            action="<?php echo e(isset($produk) ? route('admin.produk.update', $produk->id) : route('admin.produk.store')); ?>"
                            method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($produk)): ?>
                                <?php echo method_field('PUT'); ?>
                            <?php endif; ?>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="nama_produk">Nama Produk</label>
                                <div class="col-sm-10">
                                    <input type="text" id="nama_produk" name="nama_produk"
                                        class="form-control <?php $__errorArgs = ['nama_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        value="<?php echo e(old('nama_produk', $produk->nama_produk ?? '')); ?>" required />
                                    <?php $__errorArgs = ['nama_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="kategori">Kategori</label>
                                <div class="col-sm-10">
                                    <select id="kategori" name="kategori"
                                        class="form-select select2 <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <?php if(isset($produk) && $produk->kategori): ?>
                                            <option value="<?php echo e($produk->kategori); ?>" selected><?php echo e($produk->kategori); ?>

                                            </option>
                                        <?php endif; ?>
                                    </select>
                                    <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="harga">Harga</label>
                                <div class="col-sm-10">
                                    <input type="text" id="harga" name="harga"
                                        class="form-control <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        value="<?php echo e(old('harga', isset($produk) ? number_format($produk->harga, 0, ',', '.') : '')); ?>"
                                        required />
                                    <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="form-text">Masukkan Harga (Rupiah)</div>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="durasi">Durasi (hari)</label>
                                <div class="col-sm-10">
                                    <input type="number" id="durasi" name="durasi"
                                        class="form-control <?php $__errorArgs = ['durasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        value="<?php echo e(old('durasi', $produk->durasi ?? '')); ?>" required />
                                    <?php $__errorArgs = ['durasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="pendapatan_harian">Pendapatan Harian</label>
                                <div class="col-sm-10">
                                    <input type="text" id="pendapatan_harian" name="pendapatan_harian"
                                        class="form-control <?php $__errorArgs = ['pendapatan_harian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        value="<?php echo e(old('pendapatan_harian', isset($produk) ? number_format($produk->pendapatan_harian, 0, ',', '.') : '')); ?>"
                                        required />
                                    <?php $__errorArgs = ['pendapatan_harian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="form-text">Masukkan Pendapatan Harian (Rupiah)</div>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="total_pendapatan">Total Pendapatan</label>
                                <div class="col-sm-10">
                                    <input type="text" id="total_pendapatan" name="total_pendapatan" readonly
                                        class="form-control <?php $__errorArgs = ['total_pendapatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        value="<?php echo e(old('total_pendapatan', isset($produk) ? number_format($produk->total_pendapatan, 0, ',', '.') : '')); ?>"
                                        required />
                                    <?php $__errorArgs = ['total_pendapatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="form-text">Total Pendapatan akan dihitung otomatis</div>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="vip">VIP</label>
                                <div class="col-sm-10">
                                    <select id="vip" name="vip"
                                        class="form-select select2 <?php $__errorArgs = ['vip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <?php if(isset($produk) && $produk->vip): ?>
                                            <option value="<?php echo e($produk->vip); ?>" selected><?php echo e($produk->vip); ?>

                                            </option>
                                        <?php endif; ?>
                                    </select>
                                    <?php $__errorArgs = ['vip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>



                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="keterangan">Keterangan</label>
                                <div class="col-sm-10">
                                    <textarea id="keterangan" name="keterangan" rows="4"
                                        class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('keterangan', $produk->keterangan ?? '')); ?></textarea>
                                    <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row justify-content-end">
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(isset($produk) ? 'Update' : 'Simpan'); ?>

                                    </button>
                                    <a href="<?php echo e(route('admin.produk.index')); ?>" class="btn btn-secondary">Kembali</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <style>
        .right-gap {
            margin-right: 10px
        }

        .select2-container--default .select2-selection--single {
            height: 38px;
            padding-top: 4px;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 36px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            // Initialize Select2 for kategori
            $('#kategori').select2({
                placeholder: 'Pilih Kategori',
                allowClear: true,
                theme: "bootstrap-5",
                ajax: {
                    url: '<?php echo e(route('admin.produk.getkategori')); ?>',
                    dataType: 'json',
                    delay: 250,
                    processResults: function(data) {
                        return {
                            results: $.map(data, function(item) {
                                return {
                                    text: item.text,
                                    id: item.text
                                }
                            })
                        };
                    },
                    cache: true
                }
            });

            $('#vip').select2({
                placeholder: 'Pilih vip',
                allowClear: true,
                theme: "bootstrap-5",
                ajax: {
                    url: '<?php echo e(route('admin.produk.getvip')); ?>',
                    dataType: 'json',
                    delay: 250,
                    processResults: function(data) {
                        return {
                            results: $.map(data, function(item) {
                                return {
                                    text: item.text,
                                    id: item.text
                                }
                            })
                        };
                    },
                    cache: true
                }
            });

            // Format harga as number with thousand separator
            $('#harga, #pendapatan_harian, #total_pendapatan').on('input', function() {
                let value = this.value.replace(/[^0-9]/g, '');

                if (value.length > 0) {
                    value = parseInt(value).toLocaleString('id-ID');
                }

                this.value = value;
            });

            // Calculate total_pendapatan when durasi or pendapatan_harian changes
            function calculateTotal() {
                let durasi = parseInt($('#durasi').val()) || 0;
                let pendapatan_harian = $('#pendapatan_harian').val().replace(/[^0-9]/g, '');
                pendapatan_harian = parseInt(pendapatan_harian) || 0;

                let total = durasi * pendapatan_harian;
                $('#total_pendapatan').val(total.toLocaleString('id-ID'));
            }

            $('#durasi, #pendapatan_harian').on('input', calculateTotal);

            // Before form submission, remove thousand separators
            $('form').on('submit', function() {
                $('#harga').val($('#harga').val().replace(/[^0-9]/g, ''));
                $('#pendapatan_harian').val($('#pendapatan_harian').val().replace(/[^0-9]/g, ''));
                $('#total_pendapatan').val($('#total_pendapatan').val().replace(/[^0-9]/g, ''));
                return true;
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\investasi\resources\views/admin/produk/create.blade.php ENDPATH**/ ?>