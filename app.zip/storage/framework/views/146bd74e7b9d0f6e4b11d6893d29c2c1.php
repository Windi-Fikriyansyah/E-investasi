<?php $__env->startSection('title', 'Layanan'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>Layanan</h3>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Layanan</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="page-content">

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                <i class="bx bx-check-circle me-2"></i>
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card radius-10">
            <div class="card-header">
                <div class="d-flex align-items-center justify-content-between">
                    <h5 class="card-title mb-0">Daftar Layanan</h5>
                    <div>
                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                            data-bs-target="#syncModal">
                            <i class="bi bi-arrow-repeat me-1"></i> Sinkronisasi
                        </button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <div class="row">
                        <div class="col-md-3">
                            <input type="text" id="search-service-id" class="form-control" placeholder="Cari ID Layanan">
                        </div>
                        <div class="col-md-3">
                            <input type="text" id="search-name" class="form-control" placeholder="Cari Nama Layanan">
                        </div>
                        <div class="col-md-3">
                            <select id="search-supplier" class="form-select select2-kategori">
                                <option value="">Semua Kategori</option>
                                <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kategori); ?>"><?php echo e($kategori); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select id="search-type" class="form-select select2-type">
                                <option value="">Semua Type</option>
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type); ?>"><?php echo e($type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle mb-0" id="services-table" style="width: 100%">
                        <thead class="table-light">
                            <tr>
                                <th width="5%">No</th>
                                <th>Id Service</th>
                                <th>Nama Layanan</th>
                                <th>Status</th>
                                <th>Tipe</th>
                                <th>Kategori</th>
                                <th>Rate</th>
                                <th>Min</th>
                                <th>Max</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Sync Modal -->
    <div class="modal fade" id="syncModal" tabindex="-1" aria-labelledby="syncModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="syncModalLabel">Sinkronisasi Layanan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="syncForm">
                        <div class="mb-3">
                            <label for="supplier" class="form-label">Pilih Supplier</label>
                            <select class="form-select select2-supplier" id="supplier" name="supplier" required>
                                <option value="" selected disabled>-- Pilih Supplier --</option>
                                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-primary" id="confirmSync">Sinkronisasi</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <style>
        .select2-container .select2-selection--single {
            height: 38px;
        }

        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 36px;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 36px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            // Initialize Select2
            $('.select2-kategori').select2({
                placeholder: "Semua Kategori",
                theme: "bootstrap-5",
                allowClear: true
            });

            $('.select2-type').select2({
                placeholder: "Semua Type",
                theme: "bootstrap-5",
                allowClear: true
            });

            $('.select2-supplier').select2({
                placeholder: "-- Pilih Supplier --",
                theme: "bootstrap-5",
                dropdownParent: $('#syncModal')
            });

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            const table = $('#services-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(route('admin.layanan.load')); ?>",
                    type: "POST",
                    data: function(d) {
                        d.service_id = $('#search-service-id').val();
                        d.name = $('#search-name').val();
                        d.category = $('#search-supplier').val();
                        d.type = $('#search-type').val();
                    }
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'service_api_id',
                        name: 'service_api_id'
                    },
                    {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'status',
                        name: 'status',
                        render: function(data, type, row) {
                            return `
                    <div class="form-check form-switch">
                        <input class="form-check-input status-toggle"
                               type="checkbox"
                               data-id="${row.id}"
                               ${data == 1 ? 'checked' : ''}>
                    </div>
                `;
                        }
                    },
                    {
                        data: 'type',
                        name: 'type'
                    },
                    {
                        data: 'category',
                        name: 'category'
                    },
                    {
                        data: 'rate',
                        name: 'rate'
                    },
                    {
                        data: 'min',
                        name: 'min'
                    },
                    {
                        data: 'max',
                        name: 'max'
                    }
                ],
                columnDefs: [{
                    className: "text-center",
                    targets: [0, 3, 4, 5, 6, 7, 8]
                }]
            });

            $(document).on('change', '.status-toggle', function() {
                const serviceId = $(this).data('id');
                const isActive = $(this).is(':checked') ? 1 : 2;

                $.ajax({
                    url: "<?php echo e(route('admin.layanan.update-status')); ?>",
                    type: "POST",
                    data: {
                        id: serviceId,
                        status: isActive
                    },
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil',
                            text: 'Status layanan berhasil diperbarui',
                            timer: 1500,
                            showConfirmButton: false
                        });
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal',
                            text: xhr.responseJSON.message ||
                                'Terjadi kesalahan saat memperbarui status'
                        });
                        // Revert the toggle if error
                        $(this).prop('checked', !isActive);
                    }
                });
            });

            // Search functionality
            $('#search-service-id, #search-name').on('keyup', function() {
                table.ajax.reload();
            });

            $('#search-supplier, #search-type').on('change', function() {
                table.ajax.reload();
            });

            // Sync Button Handler
            $('#confirmSync').click(function() {
                const supplierId = $('#supplier').val();
                if (!supplierId) {
                    alert('Pilih supplier terlebih dahulu');
                    return;
                }

                Swal.fire({
                    title: 'Sinkronisasi',
                    text: 'Anda yakin ingin melakukan sinkronisasi layanan dari supplier ini?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, Sinkronisasi!',
                    cancelButtonText: 'Batal',
                    backdrop: `
            rgba(0,0,0,0.4)
            url("/images/nyan-cat.gif")
            left top
            no-repeat
        `,
                    customClass: {
                        container: 'swal2-zindex'
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: "<?php echo e(route('admin.layanan.sync')); ?>",
                            type: "POST",
                            data: {
                                supplier_id: supplierId
                            },
                            beforeSend: function() {
                                Swal.fire({
                                    title: 'Memproses',
                                    html: 'Sedang melakukan sinkronisasi...',
                                    allowOutsideClick: false,
                                    didOpen: () => {
                                        Swal.showLoading();
                                    },
                                    customClass: {
                                        container: 'swal2-zindex'
                                    }
                                });
                            },
                            success: function(response) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil',
                                    html: response.message +
                                        '<br>Jumlah layanan: ' + response.data
                                        .count,
                                    timer: 3000,
                                    showConfirmButton: true,
                                    customClass: {
                                        container: 'swal2-zindex'
                                    }
                                }).then(() => {
                                    table.ajax.reload();
                                    $('#syncModal').modal('hide');
                                    $('#supplier').val('').trigger(
                                        'change'); // Reset select
                                });
                            },
                            error: function(xhr) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Gagal',
                                    text: xhr.responseJSON.message ||
                                        'Terjadi kesalahan saat sinkronisasi',
                                    customClass: {
                                        container: 'swal2-zindex'
                                    }
                                });
                            }
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\smmpanel\resources\views/admin/layanan/index.blade.php ENDPATH**/ ?>