<?php $__env->startSection('content'); ?>
    <h2>Atur Rekening Bank</h2>
    <p>Kelola rekening bank Anda untuk transaksi penarikan dana.</p>

    <div class="tabs">
        <div class="tab active" data-tab="bank-list">Daftar Bank</div>
        <div class="tab" data-tab="add-bank">Tambah Bank</div>
    </div>

    <div class="tab-content active" id="bank-list">
        <div class="investment-grid">
            <?php $__empty_1 = true; $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="investment-card-modern">
                    <div class="card-header-gradient">
                        <div class="investment-icon">
                            <i class="fas fa-university"></i>
                        </div>
                        <h3 class="investment-title-modern"><?php echo e($bank->nama_bank); ?></h3>
                        <span class="category-badge">Aktif</span>
                    </div>

                    <div class="investment-details-modern">
                        <div class="detail-row">
                            <div class="detail-item full-width">
                                <div class="detail-icon">
                                    <i class="fas fa-credit-card"></i>
                                </div>
                                <div class="detail-content">
                                    <span class="detail-label">Nomor Rekening</span>
                                    <span class="detail-value"><?php echo e($bank->no_rekening); ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="detail-row">
                            <div class="detail-item full-width">
                                <div class="detail-icon">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div class="detail-content">
                                    <span class="detail-label">Nama Pemilik</span>
                                    <span class="detail-value"><?php echo e($bank->nama_pemilik); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-actions">
                        <form action="<?php echo e(route('bank.destroy', $bank->id)); ?>" method="POST" style="display: inline;"
                            class="delete-form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn-detail">
                                <i class="fas fa-trash"></i> Hapus
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="card" style="text-align: center; padding: 2rem;">
                    <i class="fas fa-university" style="font-size: 3rem; color: #0aa955; margin-bottom: 1rem;"></i>
                    <p style="color: #1e293b;">Anda belum menambahkan rekening bank</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="tab-content" id="add-bank">
        <div class="card">
            <h3 style="color: #1e293b;">Tambah Rekening Bank Baru</h3>
            <form action="<?php echo e(route('bank.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div style="margin-bottom: 1rem;">
                    <label for="nama_bank" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Nama
                        Bank</label>
                    <select name="nama_bank" id="nama_bank" class="form-control" required
                        style="width: 100%; padding: 0.75rem; border: 1px solid var(--gray); border-radius: var(--rounded-sm);">
                        <option value="">Pilih Bank</option>
                        <option value="BCA">BCA</option>
                        <option value="BRI">BRI</option>
                        <option value="Mandiri">Mandiri</option>
                        <option value="BNI">BNI</option>
                        <option value="CIMB Niaga">CIMB Niaga</option>
                        <option value="Permata">Permata</option>
                        <option value="Danamon">Danamon</option>
                        <option value="Maybank">Maybank</option>
                        <option value="OCBC NISP">OCBC NISP</option>
                        <option value="Bank Jago">Bank Jago</option>
                    </select>
                </div>

                <div style="margin-bottom: 1rem;">
                    <label for="no_rekening" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Nomor
                        Rekening</label>
                    <input type="text" name="no_rekening" id="no_rekening" required value="<?php echo e(old('no_rekening')); ?>"
                        style="width: 100%; padding: 0.75rem; border: 1px solid <?php $__errorArgs = ['no_rekening'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> #ef4444 <?php else: ?> var(--gray) <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>; border-radius: var(--rounded-sm);"
                        placeholder="Masukkan nomor rekening tanpa spasi atau tanda baca">
                    <?php $__errorArgs = ['no_rekening'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: #ef4444; font-size: 0.875rem; margin-top: 0.25rem;"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div style="margin-bottom: 1.5rem;">
                    <label for="nama_pemilik" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Nama
                        Pemilik Rekening</label>
                    <input type="text" name="nama_pemilik" id="nama_pemilik" required
                        style="width: 100%; padding: 0.75rem; border: 1px solid var(--gray); border-radius: var(--rounded-sm);"
                        placeholder="Nama harus sesuai dengan buku rekening">
                </div>

                <button type="submit" class="btn"
                    style="width: 100%; background: var(--primary); color: white; padding: 0.75rem; border: none; border-radius: var(--rounded-sm);">
                    <i class="fas fa-save"></i> Simpan Rekening
                </button>
            </form>
        </div>
    </div>


    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        // Format nomor rekening saat input
        document.getElementById('no_rekening').addEventListener('input', function(e) {
            // Hanya angka yang diperbolehkan
            this.value = this.value.replace(/[^0-9]/g, '');

            // Validasi panjang
            if (this.value.length > 30) {
                this.value = this.value.substring(0, 30);
                Swal.fire({
                    icon: 'warning',
                    title: 'Peringatan',
                    text: 'Nomor rekening maksimal 30 digit',
                });
            }
        });

        // Format nama pemilik (huruf besar di awal setiap kata)
        document.getElementById('nama_pemilik').addEventListener('input', function(e) {
            this.value = this.value.replace(/\b\w/g, function(char) {
                return char.toUpperCase();
            });
        });

        // Konfirmasi penghapusan dengan SweetAlert
        document.querySelectorAll('.delete-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Apakah Anda yakin?',
                    text: "Anda tidak akan dapat mengembalikan data ini!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, hapus!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                });
            });
        });

        // Tampilkan pesan sukses/gagal dari session dengan SweetAlert
        <?php if(session('success')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Sukses',
                text: '<?php echo e(session('success')); ?>',
                timer: 3000,
                showConfirmButton: false
            });
        <?php endif; ?>

        <?php if(session('error')): ?>
            Swal.fire({
                icon: 'error',
                title: 'Gagal',
                text: '<?php echo e(session('error')); ?>',
                timer: 3000,
                showConfirmButton: false
            });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\investasi\resources\views/bank/index.blade.php ENDPATH**/ ?>