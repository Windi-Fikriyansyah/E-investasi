<?php $__env->startSection('title', 'Api Supplier'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>Api Supplier</h3>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Api Supplier</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="page-content">

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                <i class="bx bx-check-circle me-2"></i>
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card radius-10">
            <div class="card-header">
                <div class="d-flex align-items-center justify-content-between">
                    <h5 class="card-title mb-0">Daftar Api Supplier</h5>
                    <a href="<?php echo e(route('admin.api_supplier.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-circle"></i> Tambah Supplier
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table align-middle mb-0" id="suppliers-table" style="width: 100%">
                        <thead class="table-light">
                            <tr>
                                <th width="5%">No</th>
                                <th>Nama</th>
                                <th>API Key</th>
                                <th>URL</th>
                                <th>Status</th>
                                <th width="20%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Test Connection Modal -->
    <div class="modal fade" id="testConnectionModal" tabindex="-1" aria-labelledby="testConnectionModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="testConnectionModalLabel">Hasil Test Koneksi</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="testConnectionResult">
                    <div class="text-center my-3">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p>Sedang menguji koneksi...</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            const table = $('#suppliers-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(route('admin.api_supplier.load')); ?>",
                    type: "POST"
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'api_key',
                        name: 'api_key'
                    },
                    {
                        data: 'api_url',
                        name: 'api_url'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    }
                ],
                columnDefs: [{
                        className: "text-center",
                        targets: [0, 4, 5]
                    },
                    {
                        className: "text-nowrap",
                        targets: [5]
                    }
                ]
            });

            // Test Connection
            // Test Connection
            $(document).on('click', '.test-connection-btn', function() {
                const id = $(this).data('id');
                const modal = $('#testConnectionModal');
                const resultDiv = $('#testConnectionResult');

                // Show modal with loading state
                modal.modal('show');
                resultDiv.html(`
        <div class="text-center my-3">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p>Sedang menguji koneksi ke API supplier...</p>
        </div>
    `);

                // Send test connection request
                $.ajax({
                    url: "<?php echo e(url('admin/api_supplier')); ?>/" + id + "/test-connection",
                    type: "GET",
                    success: function(response) {
                        let html = '';
                        const testedAt = response.details?.tested_at || 'N/A';

                        if (response.success) {
                            html = `
                    <div class="alert alert-success">
                        <div class="d-flex align-items-center">
                            <i class="bi bi-check-circle-fill me-2 fs-4"></i>
                            <div>
                                <h5 class="alert-heading mb-1">${response.message}</h5>
                                <div class="mt-2">
                                    <p class="mb-1"><strong>Status Code:</strong> ${response.details.status_code}</p>
                                    <p class="mb-1"><strong>Response Time:</strong> ${response.details.response_time}</p>
                                    <p class="mb-0"><strong>Tested At:</strong> ${testedAt}</p>
                                </div>
                            </div>
                        </div>
                `;

                            if (response.response) {
                                html += `
                        <hr>
                        <h6 class="mt-3">Response Data:</h6>
                        <div class="bg-light p-3 rounded" style="max-height: 300px; overflow-y: auto;">
                            <pre class="mb-0">${JSON.stringify(response.response, null, 2)}</pre>
                        </div>
                    `;
                            }

                            html += `</div>`;
                        } else {
                            html = `
                    <div class="alert alert-danger">
                        <div class="d-flex align-items-center">
                            <i class="bi bi-exclamation-triangle-fill me-2 fs-4"></i>
                            <div>
                                <h5 class="alert-heading mb-1">${response.message}</h5>
                                <div class="mt-2">
                                    <p class="mb-1"><strong>Status Code:</strong> ${response.details?.status_code || 'N/A'}</p>
                                    <p class="mb-1"><strong>Response Time:</strong> ${response.details?.response_time || 'N/A'}</p>
                                    <p class="mb-0"><strong>Tested At:</strong> ${testedAt}</p>
                                    <hr>
                                    <p class="mb-1"><strong>Error Detail:</strong></p>
                                    <div class="bg-light p-3 rounded">
                                        <pre class="mb-0">${response.error || 'Tidak ada detail error'}</pre>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                        }

                        resultDiv.html(html);
                    },
                    error: function(xhr) {
                        let errorMessage = xhr.responseJSON?.message || xhr.statusText ||
                            'Terjadi kesalahan tidak diketahui';
                        resultDiv.html(`
                <div class="alert alert-danger">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-exclamation-triangle-fill me-2 fs-4"></i>
                        <div>
                            <h5 class="alert-heading mb-1">Error!</h5>
                            <p class="mb-0">${errorMessage}</p>
                            ${xhr.status ? `<p class="mb-0 mt-2"><strong>Status:</strong> ${xhr.status}</p>` : ''}
                        </div>
                    </div>
                </div>
            `);
                    }
                });

                // Add event listener for when modal is closed
                modal.on('hidden.bs.modal', function() {
                    // Reload the table or page as needed
                    // Example: if you're using DataTables
                    if (typeof table !== 'undefined') {
                        table.ajax.reload(null, false); // false means don't reset user paging
                    }
                    // Or if you're using a simple table reload
                    // location.reload();
                });
            });
            // Toggle Status
            $(document).on('click', '.toggle-status-btn', function() {
                const url = $(this).data('url');
                const id = $(this).data('id');
                const currentStatus = $(this).data('status');

                Swal.fire({
                    title: 'Konfirmasi',
                    text: `Anda yakin ingin mengubah status supplier ini?`,
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, ubah!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: url,
                            type: 'POST',
                            data: {
                                _method: 'PATCH'
                            },
                            success: function(response) {
                                if (response.success) {
                                    Swal.fire(
                                        'Berhasil!',
                                        'Status supplier berhasil diubah.',
                                        'success'
                                    );
                                    table.ajax.reload();
                                } else {
                                    Swal.fire(
                                        'Gagal!',
                                        response.message ||
                                        'Gagal mengubah status.',
                                        'error'
                                    );
                                }
                            },
                            error: function(xhr) {
                                Swal.fire(
                                    'Error!',
                                    'Terjadi kesalahan saat mengubah status.',
                                    'error'
                                );
                            }
                        });
                    }
                });
            });

            // Delete
            $(document).on('click', '.delete-btn', function(e) {
                e.preventDefault();
                const url = $(this).data('url');

                Swal.fire({
                    title: 'Konfirmasi',
                    text: "Anda yakin ingin menghapus supplier ini?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, hapus!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: url,
                            type: 'DELETE',
                            success: function(response) {
                                if (response.success) {
                                    Swal.fire(
                                        'Terhapus!',
                                        'Supplier berhasil dihapus.',
                                        'success'
                                    );
                                    table.ajax.reload();
                                } else {
                                    Swal.fire(
                                        'Gagal!',
                                        response.message ||
                                        'Gagal menghapus supplier.',
                                        'error'
                                    );
                                }
                            },
                            error: function(xhr) {
                                Swal.fire(
                                    'Error!',
                                    'Terjadi kesalahan saat menghapus supplier.',
                                    'error'
                                );
                            }
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\smmpanel\resources\views/admin/api_suppliers/index.blade.php ENDPATH**/ ?>