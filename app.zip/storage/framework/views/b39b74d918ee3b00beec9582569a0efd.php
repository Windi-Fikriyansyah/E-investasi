<?php $__env->startSection('title', 'Order'); ?>

<?php $__env->startPush('css'); ?>
    <!-- Select2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .gradient-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
        }

        .card-modern {
            border: none;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
        }

        .card-modern:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.12);
        }

        .form-control-modern {
            border-radius: 10px;
            border: 2px solid #e3f2fd;
            padding: 12px 15px;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .form-control-modern:focus {
            border-color: #2196f3;
            box-shadow: 0 0 0 0.2rem rgba(33, 150, 243, 0.25);
            transform: translateY(-1px);
        }

        .btn-modern {
            border-radius: 25px;
            padding: 12px 30px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            border: none;
        }

        .btn-modern:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        .btn-primary-modern {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .service-info-card {
            background: linear-gradient(135deg, #e3f2fd 0%, #f3e5f5 100%);
            border: none;
            border-radius: 15px;
            padding: 20px;
            margin: 15px 0;
        }

        .service-detail-item {
            background: white;
            border-radius: 10px;
            padding: 10px 15px;
            margin: 8px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .service-detail-label {
            font-weight: 600;
            color: #555;
        }

        .service-detail-value {
            color: #2196f3;
            font-weight: 500;
        }

        .rules-card {
            background: linear-gradient(135deg, #ffebee 0%, #fce4ec 100%);
            border: none;
            border-radius: 15px;
            max-height: 80vh;
            overflow-y: auto;
        }

        .rules-header {
            background: linear-gradient(135deg, #f44336 0%, #e91e63 100%);
            color: white;
            border: none;
            border-radius: 15px 15px 0 0;
            padding: 15px 20px;
        }

        .rules-content {
            padding: 20px;
        }

        .rules-content ol {
            counter-reset: item;
            padding-left: 0;
        }

        .rules-content ol>li {
            display: block;
            margin-bottom: 15px;
            padding: 15px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            position: relative;
            padding-left: 50px;
        }

        .rules-content ol>li:before {
            content: counter(item);
            counter-increment: item;
            position: absolute;
            left: 15px;
            top: 15px;
            background: linear-gradient(135deg, #f44336 0%, #e91e63 100%);
            color: white;
            width: 25px;
            height: 25px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 12px;
        }

        .section-title {
            color: #333;
            font-weight: 700;
            margin: 25px 0 15px 0;
            padding-bottom: 10px;
            border-bottom: 3px solid #2196f3;
            display: inline-block;
        }

        .alert-note {
            background: linear-gradient(135deg, #fff3e0 0%, #ffecb3 100%);
            border: none;
            border-radius: 10px;
            padding: 15px;
            margin: 15px 0;
            border-left: 4px solid #ff9800;
        }

        .select2-container--bootstrap-5 .select2-selection {
            border-radius: 10px !important;
            border: 2px solid #e3f2fd !important;
            padding: 5px 10px !important;
            min-height: 45px !important;
        }

        .select2-container--bootstrap-5 .select2-selection--single .select2-selection__rendered {
            padding-top: 5px !important;
        }

        .select2-icon {
            margin-right: 8px;
        }

        .input-group-text {
            background: linear-gradient(135deg, #e3f2fd 0%, #f3e5f5 100%);
            border: 2px solid #e3f2fd;
            border-radius: 10px 0 0 10px;
            font-weight: 600;
        }

        .price-display {
            font-size: 18px;
            font-weight: 600;
            color: #2196f3;
        }

        .form-label {
            font-weight: 600;
            color: #555;
            margin-bottom: 8px;
        }

        .form-text {
            color: #666;
            font-size: 12px;
        }

        /* Scrollbar styling */
        .rules-card::-webkit-scrollbar {
            width: 8px;
        }

        .rules-card::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }

        .rules-card::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, #f44336 0%, #e91e63 100%);
            border-radius: 10px;
        }

        .rules-card::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, #d32f2f 0%, #c2185b 100%);
        }

        /* Animation for form validation */
        .is-invalid {
            animation: shake 0.5s;
        }

        @keyframes shake {

            0%,
            100% {
                transform: translateX(0);
            }

            25% {
                transform: translateX(-5px);
            }

            75% {
                transform: translateX(5px);
            }
        }

        /* Loading animation */
        .loading-spinner {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid #f3f3f3;
            border-top: 2px solid #2196f3;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-right: 8px;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .card-modern {
                margin-bottom: 20px;
            }

            .btn-modern {
                width: 100%;
                margin-top: 15px;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <div class="card card-modern">
                    <div class="card-header gradient-header">
                        <h3 class="card-title mb-0">
                            <i class="fas fa-shopping-cart me-2"></i>
                            Buat Pesanan Baru
                        </h3>
                    </div>
                    <div class="card-body p-4">
                        <form id="orderForm">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-4">
                                        <label for="category" class="form-label">
                                            <i class="fas fa-folder me-2"></i>Kategori
                                        </label>
                                        <select class="form-control form-control-modern select2-with-icons" id="category"
                                            name="category" style="width: 100%;">
                                            <option value="">Pilih Kategori</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category); ?>"
                                                    data-icon="<?php echo e(getSocialMediaIconClass($category)); ?>"><?php echo e($category); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-4">
                                        <label for="service" class="form-label">
                                            <i class="fas fa-cogs me-2"></i>Layanan
                                        </label>
                                        <select class="form-control form-control-modern select2" id="service"
                                            name="service" style="width: 100%;" disabled>
                                            <option value="">Pilih Layanan</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group mb-4">
                                        <label class="form-label">
                                            <i class="fas fa-info-circle me-2"></i>Informasi Layanan
                                        </label>
                                        <div class="service-info-card">
                                            <p id="serviceDescription" class="mb-3"
                                                style="color: #666; font-style: italic;">
                                                Pilih layanan untuk melihat detail
                                            </p>
                                            <div id="serviceDetails">
                                                <div class="service-detail-item">
                                                    <span class="service-detail-label">Min. Pesan:</span>
                                                    <span class="service-detail-value" id="serviceMin">0</span>
                                                </div>
                                                <div class="service-detail-item">
                                                    <span class="service-detail-label">Max. Pesan:</span>
                                                    <span class="service-detail-value" id="serviceMax">0</span>
                                                </div>
                                                <div class="service-detail-item">
                                                    <span class="service-detail-label">Refill:</span>
                                                    <span class="service-detail-value" id="serviceRefill">-</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group mb-4">
                                        <label for="link" class="form-label">
                                            <i class="fas fa-link me-2"></i>Link/Username
                                        </label>
                                        <input type="text" class="form-control form-control-modern" id="link"
                                            name="link" placeholder="Masukkan link/username">
                                        <small id="linkHelp" class="form-text">
                                            <i class="fas fa-exclamation-triangle me-1"></i>
                                            Pastikan link/username sesuai format
                                        </small>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-4">
                                        <label for="quantity" class="form-label">
                                            <i class="fas fa-hashtag me-2"></i>Jumlah
                                        </label>
                                        <input type="number" class="form-control form-control-modern" id="quantity"
                                            name="quantity" min="1" value="1">
                                        <small id="quantityHelp" class="form-text">
                                            Min: <span id="minQuantity" class="text-primary fw-bold">1</span>,
                                            Max: <span id="maxQuantity" class="text-primary fw-bold">0</span>
                                        </small>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-4">
                                        <label for="price" class="form-label">
                                            <i class="fas fa-money-bill-wave me-2"></i>Harga
                                        </label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Rp</span>
                                            </div>
                                            <input type="text" class="form-control form-control-modern price-display"
                                                id="price" name="price" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="text-end">
                                <button type="submit" class="btn btn-primary-modern btn-modern">
                                    <i class="fas fa-shopping-cart me-2"></i>
                                    Buat Pesanan
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-12">
                <div class="card card-modern rules-card">
                    <div class="card-header rules-header">
                        <h3 class="card-title mb-0">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            RULES - WAJIB BACA !!!
                        </h3>
                    </div>
                    <div class="card-body rules-content">
                        <ol>
                            <li>Pastikan Anda menginput link yang benar sesuai format yang ada di keterangan, karena kami
                                tidak
                                bisa membatalkan pesanan.</li>
                            <li>Jangan menggunakan lebih dari satu layanan sekaligus untuk username/link yang sama. Harap
                                tunggu
                                status completed pada orderan sebelumnya baru melakukan orderan kepada username/ link yang
                                sama.
                                Hal ini tidak akan membantu mempercepat orderan Anda karena kedua orderan bisa jadi
                                berstatus
                                completed tetapi hanya tercapai target dari salah satu orderan dan tidak ada pengembalian
                                dana.
                            </li>
                            <li>Setelah order dimasukan, jika username/link yang diinput tidak ditemukan
                                (diganti/diprivate/dihapus), orderan akan otomatis menjadi completed dan tidak ada
                                pengembalian
                                dana.</li>
                            <li>Kesalahan pembeli, bukan tanggung jawab admin, karena panel ini serba otomatis, jadi
                                hati-hati
                                dan perhatikan link sebelum order dan tidak ada pengembalian dana!</li>
                            <li>Jika Orderan statusnya partial & canceled, saldo otomatis di refund dan bisa order ulang!
                            </li>
                            <li>Jumlah maks menunjukkan kapasitas layanan tersebut untuk satu target (akun/link) bukan
                                menunjukkan kapasitas maks sekali order. Apabila Anda telah menggunakan semua kapasitas maks
                                layanan, Anda tidak bisa menggunakan layanan itu lagi dan harus menggunakan layanan yang
                                lain.
                                Oleh karenannya kami menyediakan banyak layanan dengan kapasitas maks yang lebih besar.</li>
                            <li>Informasi yang terdapat pada kolom keterangan (speed, drop rate) bersifat estimasi untuk
                                membedakan layanan yang satu dan lainnya. Informasi bisa jadi tidak akurat tergantung dari
                                performa server dan jumlah orderan yang masuk pada server tersebut. Anda dapat report
                                setelah 24
                                jam orderan dikirim.</li>
                            <li>Dengan melakukan orderan Anda dianggap sudah memahami dan setuju Syarat dan Ketentuan Indo
                                SMM.
                            </li>
                        </ol>

                        <h4 class="section-title">
                            <i class="fas fa-tachometer-alt me-2"></i>
                            KETENTUAN SPEED UP
                        </h4>
                        <ol>
                            <li>Definisi speedup adalah proses boost up layanan yang stuck orderannya / belum jalan sama
                                sekali
                                setelah lebih dari 24 jam. Speed up 24 jam tidak berlaku untuk layanan yang ada tulisan SLOW
                                pada nama layananya atau pada harga layanan kolom speed memang lambat prosesnya.</li>
                            <li>Apabila sudah melewati estimasi waktu speed layanan yang tertera pada halaman Daftar Layanan
                                dan
                                orderan masih pending / in progress / processing, silahkan request speedup dengan melaporkan
                                order ID kepada CS.</li>
                            <li>Request speed up nantinya akan di proses dalam waktu 1x24 jam. Batas maksimal request speed
                                up
                                adalah 1x dalam 1 hari untuk satu order id yang sama.</li>
                            <li>Jika dalam 1x24 jam status orderan masih belum completed, silahkan lakukan request speed up
                                untuk yang kedua kalinya. Kemudian tunggu hingga 1x24 jam.</li>
                        </ol>

                        <div class="alert-note">
                            <strong><i class="fas fa-sticky-note me-2"></i>NOTE:</strong><br>
                            Kami hanya menerima request, bukan memantau status orderan belum completed secara berkala.
                        </div>

                        <h4 class="section-title">
                            <i class="fas fa-redo-alt me-2"></i>
                            KETENTUAN REFILL
                        </h4>
                        <ol>
                            <li>Definisi refill adalah proses pengisian ulang layanan (followers / view /lainnya) yang
                                mengalami
                                drop parah (lebih dari 30%) sejak orderan statusnya completed. Status partial, tidak dapat
                                di
                                refill.</li>
                            <li>Refill hanya berlaku untuk layanan yang memberikan garansi refill. Setiap layanan memberikan
                                masa garansi berbeda-beda (silahkan lihat dibagian keterangan layanan).</li>
                            <li>Refill tidak berlaku apabila jumlah followers / views / subscribers dll saat ini berada
                                dibawah
                                start count.</li>
                            <li>Refill tidak berlaku apabila status orderan Anda partial.</li>
                            <li>Untuk klaim garansi refill ada 2 cara, yaitu pertama, ada yang langsung menggunakan tombol
                                refill di riwayat order, kedua, refill manual silahkan laporkan order id kepada CS melalui
                                Tiket
                                atau WhatsApp.</li>
                            <li>Pastikan akun tidak di private, jika private refill tidak dapat diproses.</li>
                            <li>Proses refill bisa memakan waktu 3-5 hari atau lebih tergantung jenis layanan.</li>
                            <li>Jika refill belum masuk dalam 3-5 hari kedepan, silahkan follow up kembali ke CS.</li>
                            <li>Jika tidak ada follow up dari member kepada CS, maka kami menganggap bahwa request refill
                                sudah
                                masuk.</li>
                            <li>Selama proses refill belum selesai, tidak diperbolehkan untuk order ulang ke link yang sama
                                atau
                                garansi hangus / tidak dapat direfill karena sudah naik.</li>
                        </ol>

                        <div class="alert-note">
                            <strong><i class="fas fa-exclamation-circle me-2"></i>PENTING!</strong><br>
                            Akun private = tidak bisa refill<br>
                            Akun diubah usernamenya = tidak bisa refill<br>
                            Request Refill tidak dapat dilakukan jika waktu masa garansi telah habis. Sehingga komplain
                            refill
                            setelah expired tidak diterima. Kami hanya menerima request, bukan memantau jumlah refill sudah
                            terpenuhi atau belum secara berkala.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <!-- Select2 -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            // Initialize Select2 with modern styling
            $('.select2-with-icons').select2({
                theme: 'bootstrap-5',
                templateResult: formatOptionWithIcon,
                templateSelection: formatOptionWithIcon,
                placeholder: "Pilih Kategori",
                allowClear: true
            });

            $('#service').select2({
                theme: 'bootstrap-5',
                placeholder: "Pilih Layanan",
                allowClear: true
            });

            function formatOptionWithIcon(option) {
                if (!option.id) return option.text;

                const iconClass = $(option.element).data('icon');
                if (!iconClass) return option.text;

                const $wrapper = $(
                    '<span><span class="select2-icon"><i class="' + iconClass + '"></i></span>' + option.text +
                    '</span>'
                );

                return $wrapper;
            }

            // Enhanced category change handler
            $('#category').on('change', function() {
                var category = $(this).val();

                // Reset service dropdown
                $('#service').val(null).trigger('change');
                $('#service').empty();
                $('#service').append('<option value="">Pilih Layanan</option>');

                if (category) {
                    // Show loading state with spinner
                    $('#service').prop('disabled', true);
                    $('#service').html(
                        '<option value=""><span class="loading-spinner"></span>Memuat layanan...</option>'
                    );

                    $.ajax({
                        url: '/order/get-services/' + encodeURIComponent(category),
                        type: 'GET',
                        success: function(data) {
                            $('#service').empty();
                            $('#service').append('<option value="">Pilih Layanan</option>');

                            if (data.length > 0) {
                                $.each(data, function(key, service) {
                                    var pricePer1000 = service.price;
                                    var option = new Option(
                                        service.service_api_id + ' - ' + service
                                        .name + ' - Rp' + formatRupiah(
                                            pricePer1000) + '/1000',
                                        service.id,
                                        false,
                                        false
                                    );

                                    // Add data attributes
                                    $(option).data('price', pricePer1000);
                                    $(option).data('min', service.min);
                                    $(option).data('max', service.max);
                                    $(option).data('refill', service.refill || '-');
                                    $(option).data('speed', service.speed || '-');
                                    $(option).data('drop', service.drop || '-');
                                    $(option).data('warranty', service.warranty || '-');
                                    $(option).data('description', service.description ||
                                        '-');

                                    $('#service').append(option);
                                });

                                $('#service').prop('disabled', false);
                            } else {
                                $('#service').html(
                                    '<option value="">Tidak ada layanan tersedia</option>');
                            }

                            $('#service').trigger('change');
                        },
                        error: function(xhr) {
                            console.error(xhr);
                            $('#service').html(
                                '<option value="">Gagal memuat layanan</option>');
                            // Add error styling
                            $('#service').addClass('is-invalid');
                            setTimeout(() => {
                                $('#service').removeClass('is-invalid');
                            }, 2000);
                        }
                    });
                } else {
                    $('#service').prop('disabled', true);
                    resetServiceDetails();
                }
            });

            // Enhanced service change handler
            // Enhanced service change handler
            $('#service').on('change', function() {
                var selectedOption = $(this).find('option:selected');

                if (selectedOption.val()) {
                    // Update min and max quantity
                    var min = selectedOption.data('min');
                    var max = selectedOption.data('max');
                    $('#minQuantity').text(min);
                    $('#maxQuantity').text(max);
                    $('#quantity').attr('min', min);
                    $('#quantity').attr('max', max);
                    $('#quantity').val(min);

                    // Update service details with animation
                    $('#serviceDescription').fadeOut(200, function() {
                        $(this).text(selectedOption.data('description')).fadeIn(200);
                    });

                    $('#serviceMin').text(min);
                    $('#serviceMax').text(max);

                    // No need to modify here as the controller already formats it
                    $('#serviceRefill').text(selectedOption.data('refill'));

                    // Calculate initial price
                    calculatePrice();
                } else {
                    resetServiceDetails();
                }
            });

            // Enhanced quantity change handler
            $('#quantity').on('change input', function() {
                var min = parseInt($('#minQuantity').text());
                var max = parseInt($('#maxQuantity').text());
                var value = parseInt($(this).val());

                // Validate quantity range
                if (value < min || value > max) {
                    $(this).addClass('is-invalid');
                } else {
                    $(this).removeClass('is-invalid');
                }

                calculatePrice();
            });

            // Enhanced form submission
            $('#orderForm').on('submit', function(e) {
                e.preventDefault();

                // Remove previous validation classes
                $('.form-control').removeClass('is-invalid');

                let isValid = true;

                // Validate form fields
                if (!$('#category').val()) {
                    $('#category').next('.select2-container').find('.select2-selection').addClass(
                        'is-invalid');
                    showAlert('Pilih kategori terlebih dahulu', 'warning');
                    isValid = false;
                }

                if (!$('#service').val()) {
                    $('#service').next('.select2-container').find('.select2-selection').addClass(
                        'is-invalid');
                    showAlert('Pilih layanan terlebih dahulu', 'warning');
                    isValid = false;
                }

                if (!$('#link').val()) {
                    $('#link').addClass('is-invalid');
                    showAlert('Masukkan link/username terlebih dahulu', 'warning');
                    isValid = false;
                }

                var quantity = parseInt($('#quantity').val());
                var min = parseInt($('#minQuantity').text());
                var max = parseInt($('#maxQuantity').text());

                if (quantity < min || quantity > max) {
                    $('#quantity').addClass('is-invalid');
                    showAlert('Jumlah pesanan harus antara ' + min + ' dan ' + max, 'warning');
                    isValid = false;
                }

                if (isValid) {
                    // Show loading state
                    const submitBtn = $(this).find('button[type="submit"]');
                    submitBtn.prop('disabled', true).html(
                        '<span class="loading-spinner"></span>Memproses...');

                    // Simulate API call
                    setTimeout(() => {
                        showAlert('Pesanan berhasil dibuat!', 'success');
                        submitBtn.prop('disabled', false).html(
                            '<i class="fas fa-shopping-cart me-2"></i>Buat Pesanan');
                        // Reset form or redirect
                        // this.reset();
                    }, 2000);
                }
            });

            function calculatePrice() {
                var selectedOption = $('#service').find('option:selected');
                var pricePer1000 = selectedOption.data('price');
                var quantity = parseInt($('#quantity').val()) || 0;

                if (selectedOption.val() && quantity > 0) {
                    var totalPrice = (pricePer1000 * quantity) / 1000;
                    $('#price').val(formatRupiah(totalPrice));
                } else {
                    $('#price').val('');
                }
            }

            function resetServiceDetails() {
                $('#price').val('');
                $('#minQuantity').text('1');
                $('#maxQuantity').text('0');
                $('#quantity').val('1');
                $('#quantity').attr('min', 1);
                $('#quantity').attr('max', 0);
                $('#serviceDescription').text('Pilih layanan untuk melihat detail');
                $('#serviceMin').text('0');
                $('#serviceMax').text('0');
                $('#serviceRefill').text('-');
            }

            function formatRupiah(angka) {
                var number_string = angka.toString(),
                    sisa = number_string.length % 3,
                    rupiah = number_string.substr(0, sisa),
                    ribuan = number_string.substr(sisa).match(/\d{3}/g);

                if (ribuan) {
                    separator = sisa ? '.' : '';
                    rupiah += separator + ribuan.join('.');
                }

                return rupiah;
            }

            function showAlert(message, type) {
                // Create alert element
                const alertClass = type === 'success' ? 'alert-success' :
                    type === 'warning' ? 'alert-warning' : 'alert-danger';

                const alertHtml = `
                    <div class="alert ${alertClass} alert-dismissible fade show" role="alert" style="position: fixed; top: 20px; right: 20px; z-index: 9999; min-width: 300px;">
                        <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle'} me-2"></i>
                        ${message}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                `;

                $('body').append(alertHtml);

                // Auto remove after 3 seconds
                setTimeout(() => {
                    $('.alert').fadeOut(300, function() {
                        $(this).remove();
                    });
                }, 3000);
            }

            // Add smooth scroll to top when form is submitted
            $('html, body').animate({
                scrollTop: 0
            }, 'smooth');

            // Add input focus effects
            $('.form-control-modern').on('focus', function() {
                $(this).parent().addClass('focused');
            }).on('blur', function() {
                $(this).parent().removeClass('focused');
            });

            // Add loading effect for Select2
            $('#category, #service').on('select2:open', function() {
                $('.select2-search__field').attr('placeholder', 'Ketik untuk mencari...');
            });

            // Initialize tooltips if Bootstrap 5 is available
            if (typeof bootstrap !== 'undefined') {
                var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                    return new bootstrap.Tooltip(tooltipTriggerEl);
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\smmpanel\resources\views/order/index.blade.php ENDPATH**/ ?>